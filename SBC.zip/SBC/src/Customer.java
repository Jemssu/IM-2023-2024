import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Customer {
    
    //INITIALIZATION OF VARIABLES
    String customerFName, customerLName, customerContactNumber;
    int customerID;

    // JDBC URL, username, and password of MySQL server
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/prj_tan";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "";

    // Connection object
    private Connection connection;

    //Constructor

    public Customer() {
        try {
            connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            if (connection != null) {
                System.out.println("Connected to the database!");
            }
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database!");
            e.printStackTrace();
        }
    }


    public Customer(String customerFName, String customerLName, String customerContactNumber) {
        this.customerFName = customerFName;
        this.customerLName = customerLName;
        this.customerContactNumber = customerContactNumber;
    }
    

    //SETTERS AND GETTERS
    public String getCustomerFName() {
        return customerFName;
    }
    
    public void setCustomerFName(String customerFName) {
        this.customerFName = customerFName;
    }
    
    public String getCustomerLName() {
        return customerLName;
    }
    
    public void setCustomerLName(String customerLName) {
        this.customerLName = customerLName;
    }

    public String getCustomerFullName() { 
        return customerFName + " " + customerLName;
    }
    
    // Method to retrieve customer contact number
    public String getCustomerContactNumber(String firstName, String lastName) {
        String sql = "SELECT Customer_ContactNum FROM tbl_customer WHERE Customer_FirstName = ? AND Customer_LastName = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, firstName);
            preparedStatement.setString(2, lastName);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getString("Customer_ContactNum");
            } else {
                return null; // Return null if customer does not exist
            }
        } catch (SQLException e) {
            System.out.println("SQL Error: Failed to retrieve customer contact number.");
            e.printStackTrace();
            return null;
        }
    }
    
    public void setCustomerContactNumber(String customerContactNumber) {
        this.customerContactNumber = customerContactNumber;
    }    

    


    //METHODS
    
    // Add the customer
    public boolean addCustomer(String customerFName, String customerLName, String customerContactNumber) {
        // Check if the contact number is 11 digits
        if (customerContactNumber.length() != 11) {
            System.out.println("Invalid contact number. Contact number must be 11 digits.");
            return false;
        }

        // Check if the customer already exists
        if (doesCustomerExist(customerFName, customerLName)) {
            System.out.println("Customer already exists. Cannot add duplicate customer.");
            return false;
        }

        // If the contact number is valid and the customer does not exist, add the customer
        String sql = "INSERT INTO tbl_customer (Customer_FirstName, Customer_LastName, Customer_ContactNum) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, customerFName);
            preparedStatement.setString(2, customerLName);
            preparedStatement.setString(3, customerContactNumber);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Customer added successfully!");
                return true;
            } else {
                System.out.println("Failed to add customer.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("SQL Error: Failed to add customer.");
            e.printStackTrace();
            return false;
        }
    }


    //CHECKERS

    public boolean doesCustomerExist(String customerFName, String customerLName) {
        String sql = "SELECT Customer_ID FROM tbl_customer WHERE Customer_FirstName = ? AND Customer_LastName = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, customerFName);
            preparedStatement.setString(2, customerLName);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int customerID = resultSet.getInt("Customer_ID");
                System.out.println("Customer with ID " + customerID + " already exists.");
                return true;
            } else {
                System.out.println("Customer does not exist.");
                return false;
            }
        } catch (SQLException e) {
            System.out.println("SQL Error: Failed to check if customer exists.");
            e.printStackTrace();
            return false;
        }
    }

    // Method to retrieve customer ID if it exists
    public int getCustomerIDIfExists(String customerFName, String customerLName) {
        String sql = "SELECT Customer_ID FROM tbl_customer WHERE Customer_FirstName = ? AND Customer_LastName = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, customerFName);
            preparedStatement.setString(2, customerLName);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt("Customer_ID");
            } else {
                return -1; // Return -1 if customer does not exist
            }
        } catch (SQLException e) {
            System.out.println("SQL Error: Failed to check if customer exists.");
            e.printStackTrace();
            return -1;
        }
    }

    // Method to update customer's contact number
    public boolean updateCustomerContactNumber(int customerID, String newContactNumber) {
        // SQL query to update contact number
        String sql = "UPDATE tbl_customer SET Customer_ContactNum = ? WHERE Customer_ID = ?";
        
        try (
            // Try-with-resources to automatically close resources
            Connection conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement(sql);
        ) {
            // Set parameters
            pstmt.setString(1, newContactNumber);
            pstmt.setInt(2, customerID);

            // Execute the update statement
            int rowsUpdated = pstmt.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete customer from database
    public boolean deleteCustomer(int customerID) {
        // SQL query to delete customer
        String sql = "DELETE FROM tbl_customer WHERE Customer_ID = ?";

        try (
            // Try-with-resources to automatically close resources
            Connection conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement(sql);
        ) {
            // Set parameter
            pstmt.setInt(1, customerID);

            // Execute the delete statement
            int rowsDeleted = pstmt.executeUpdate();
            return rowsDeleted > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to get customer ID by first name and last name
    public int getCustomerID(String firstName, String lastName) {
        // Initialize customer ID
        int customerID = -1;

        // SQL query to retrieve customer ID by first name and last name
        String sql = "SELECT Customer_ID FROM tbl_customer WHERE Customer_FirstName = ? AND Customer_LastName = ?";

        try (
            // Try-with-resources to automatically close resources
            Connection conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement(sql);
        ) {
            // Set parameters
            pstmt.setString(1, firstName);
            pstmt.setString(2, lastName);

            // Execute query
            ResultSet rs = pstmt.executeQuery();

            // Check if customer exists
            if (rs.next()) {
                customerID = rs.getInt("Customer_ID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return customerID;
    }


    // CLOSE CONNECTION
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("Connection closed.");
            }
        } catch (SQLException e) {
            System.out.println("Failed to close the connection!");
            e.printStackTrace();
        }
    }

    // Method to update customer details in the database
    public void updateCustomer(int customerID, String newFirstName, String newLastName, String newContactNumber) {
        // SQL query to update customer details
        String sql = "UPDATE tbl_customer SET Customer_FirstName = ?, Customer_LastName = ?, Customer_ContactNum = ? WHERE Customer_ID = ?";
        
        try (
            // Establish connection and prepare statement
            Connection conn = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
            PreparedStatement pstmt = conn.prepareStatement(sql);
        ) {
            // Set parameters
            pstmt.setString(1, newFirstName);
            pstmt.setString(2, newLastName);
            pstmt.setString(3, newContactNumber);
            pstmt.setInt(4, customerID);
            
            // Execute the update statement
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer details updated successfully!");
            } else {
                System.out.println("Failed to update customer details.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }



}
