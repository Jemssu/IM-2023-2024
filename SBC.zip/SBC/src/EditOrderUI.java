import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.*;
import java.util.regex.Pattern;

public class EditOrderUI {

    int oldItemId = 0;
    int orderID; // Declare orderID field
    boolean saveMode = false;
    
    // Constructor
    // Constructor
    public EditOrderUI(int orderID) {
        this.orderID = orderID; // Initialize orderID field
        openEditItems(orderID);
    }
    
    Order order = new Order();

    public void main(String[] args) { 

        // Check if orderID exists in tbl_order
        boolean orderExists = checkOrderExists(orderID);

        if (!orderExists) {
            JOptionPane.showMessageDialog(null, "Order ID does not exist.", "Error", JOptionPane.ERROR_MESSAGE);
            return; // Exit the program
        }

        // Open edit items interface
        openEditItems(orderID);
    }

    // Method to check if orderID exists in tbl_order
    public boolean checkOrderExists(int orderID) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean exists = false;

        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");

            // Prepare SQL statement to check if orderID exists
            String sql = "SELECT COUNT(*) AS count FROM tbl_order WHERE Order_ID = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderID);

            // Execute query
            resultSet = preparedStatement.executeQuery();

            // Check if result set has any rows
            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                exists = (count > 0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error checking if order exists: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return exists;
    }

    private JFrame frame;

    // Method to create and return the JFrame instance
    public JFrame getFrame() {
        return frame;
    }


    public void openEditItems(int orderID) {   
        // Create JFrame
        frame = new JFrame("Edit Order -- Order ID: " + orderID);
        frame.setSize(850, 420);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null);

        // Panel for fields and buttons
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(null);
        leftPanel.setBounds(10, 10, 400, 360);
        leftPanel.setBorder(BorderFactory.createTitledBorder("Item Details"));

        // Create fields and labels
        JLabel itemIdLabel = new JLabel("Item ID:");
        JTextField itemIdField = new JTextField();
        itemIdLabel.setBounds(20, 20, 80, 20);
        itemIdField.setBounds(110, 20, 160, 20);
        JLabel itemNameLabel = new JLabel("Item Name:");
        JTextField itemNameField = new JTextField();
        itemNameLabel.setBounds(20, 42, 80, 20);
        itemNameField.setBounds(110, 42, 160, 20);
        JLabel itemPriceLabel = new JLabel("Item Price:");
        JTextField itemPriceField = new JTextField();
        itemPriceLabel.setBounds(20, 64, 80, 20);
        itemPriceField.setBounds(110, 64, 160, 20);
        JLabel quantityLabel = new JLabel("Quantity:");
        JTextField quantityField = new JTextField();
        quantityLabel.setBounds(20, 86, 80, 20);
        quantityField.setBounds(110, 86, 160, 20);
        leftPanel.add(itemIdLabel);
        leftPanel.add(itemIdField);
        leftPanel.add(itemPriceField);
        leftPanel.add(itemPriceLabel);
        leftPanel.add(itemNameLabel);
        leftPanel.add(itemNameField);
        leftPanel.add(quantityLabel);
        leftPanel.add(quantityField);

        // Add buttons
        JButton addButton = new JButton("Add Item");
        addButton.setBounds(20, 110, 120, 20);
        JButton removeButton = new JButton("Remove Item");
        removeButton.setBounds(150, 110, 120, 20);
        JButton editButton = new JButton("Edit Item");
        editButton.setBounds(20, 132, 120, 20);
        JButton confirmButton = new JButton("Confirm");
        confirmButton.setBounds(150, 132, 120, 20);
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBounds(20, 154, 120, 20);

        leftPanel.add(addButton);
        leftPanel.add(editButton);
        leftPanel.add(confirmButton);
        leftPanel.add(removeButton);
        leftPanel.add(cancelButton);

        // Add leftPanel to the frame
        frame.add(leftPanel);

        // Create table model
        DefaultTableModel tableModel = new DefaultTableModel();
        JTable table = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Add columns to the model
        tableModel.addColumn("Item ID");
        tableModel.addColumn("Item Name");
        tableModel.addColumn("Quantity");
        tableModel.addColumn("Price");
        tableModel.addColumn("Subtotal");

        // Fetch data and populate the table
        fetchData(orderID, tableModel);

        // Create JScrollPane to contain the table
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(420, 10, 400, 360);
        frame.add(scrollPane);

        setFieldsAndButtonsEnabled(false, itemIdField, itemNameField, quantityField, itemPriceField);
        confirmButton.setEnabled(false);

        // Set frame visible
        frame.setVisible(true);

        // Define a ListSelectionListener for the table
        ListSelectionListener selectionListener = new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Check if the selection is adjusting
                if (!e.getValueIsAdjusting()) {
                    // Get the selected row index
                    int selectedRow = table.getSelectedRow();
                    
                    // Fill fields with data from the selected row
                    if (selectedRow != -1) {
                        String itemId = table.getValueAt(selectedRow, 0).toString();
                        String itemName = table.getValueAt(selectedRow, 1).toString();
                        String quantity = table.getValueAt(selectedRow, 2).toString();
                        String price = table.getValueAt(selectedRow, 3).toString();
                        
                        itemIdField.setText(itemId);
                        itemNameField.setText(itemName);
                        quantityField.setText(quantity);
                        itemPriceField.setText(price);
                    }
                }
            }
        };

        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (!saveMode) { // If not in save mode, switch to save mode
                    addButton.setBackground(Color.GREEN); // Change button color
                    table.setEnabled(false);
                    removeButton.setEnabled(false);
                    editButton.setEnabled(false);
                    itemIdField.setText("");
                    itemPriceField.setText("");
                    quantityField.setText("");
                    itemNameField.setText("");
        
                    addButton.setText("Save"); // Change button text
                    setFieldsAndButtonsEnabled(true, itemIdField, quantityField, itemPriceField); // Enable fields
                    saveMode = true; // Set save mode to true
                } else { // If in save mode, perform save operation
                    int itemId = 0;
        
                    try {
                        itemId = Integer.parseInt(itemIdField.getText().trim());
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid Item ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
        
                    // Check if item ID exists in the product_size table
                    if (!isValidItemID(itemId)) {
                        JOptionPane.showMessageDialog(null, "Invalid Item ID.", "Error", JOptionPane.ERROR_MESSAGE);
                        itemIdField.setText(""); // Clear the item ID field
                        return;
                    }
        
                    String quantity = quantityField.getText().trim();
        
                    // Check if quantity is a positive integer
                    if (!isValidQuantity(quantity)) {
                        JOptionPane.showMessageDialog(null, "Invalid Quantity. Quantity must be a positive integer.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    // Get the item price from the database or from the user
                    double price = Double.parseDouble(itemPriceField.getText().trim());
                    try {
                        if (price <= 0) {
                            JOptionPane.showMessageDialog(null, "Invalid Price. Price must be a positive number.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid Price. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
        
                    // Get the item name corresponding to the item ID
                    String itemName = itemNameField.getText().trim();
        
                    if (checkDuplicateItem(orderID, itemId)) {
                        JOptionPane.showMessageDialog(null, "You have already entered this item.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
        

                    
        
                    // Calculate subtotal based on the price of the item
                    int qty = Integer.parseInt(quantity);
                    double subtotal = price * qty;
        
                    // Add the item to the database
                    if (addItemToDatabase(orderID, itemId, itemName, qty, price, subtotal)) {
                        // Add the item to the table along with the item name
                        tableModel.addRow(new Object[]{itemId, itemName, quantity, price, subtotal});
        
                        // Clear item ID and quantity fields
                        itemIdField.setText("");
                        itemNameField.setText("");
                        itemPriceField.setText("");
                        quantityField.setText("");
        
                        updateTable(tableModel, orderID);
                        saveMode = false;
        
                        // Reset button to save mode
                        addButton.setBackground(UIManager.getColor("Button.background"));
                        addButton.setText("Add Item");
                        table.setEnabled(true);
                        removeButton.setEnabled(true);
                        editButton.setEnabled(true);
                    }
                }
            }
        });
        
        
        // Remove Item Button Action Listener
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the index of the selected row
                int selectedRow = table.getSelectedRow();

                // Check if a row is selected
                if(selectedRow == -1) {
                    JOptionPane.showMessageDialog(null, "Please select an item to remove.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Get the Item ID from the selected row
                int itemIdToRemove = (int) tableModel.getValueAt(selectedRow, 0);

                // Prompt the user for confirmation
                int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove this item?", "Confirm Removal", JOptionPane.YES_NO_OPTION);

                // If the user confirms removal
                if (choice == JOptionPane.YES_OPTION) {
                    // Remove the selected row from the table
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(null, "Item removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    
                    // Delete the row from the database based on Item ID
                    deleteItemFromDatabase(itemIdToRemove);

                    updateTable(tableModel, orderID);
                }
            }
        });


        // Add KeyListener to itemIdField
        itemIdField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                // Check if the entered key is a number (0-9)
                if (Character.isDigit(e.getKeyChar())) {
                    int itemId = 0;
                    try {
                        itemId = Integer.parseInt(itemIdField.getText().trim());
                        // Call getItemName method to get the item name
                        String itemName = order.getItemName(itemId); // Define this method
                        if (itemName != null) {
                            // If the item name exists, enable itemNameField and set its text
                            itemNameField.setText(itemName);
                            // Fetch item price from tbl_product_size
                            double price = fetchItemPrice(itemId);
                            // Set item price in the price field
                            itemPriceField.setText(String.valueOf(price));
                        } else {
                            itemNameField.setText("");
                            itemPriceField.setText(""); // Clear price field if item not found
                        }
                    } catch (NumberFormatException ex) {
                        // Handle non-integer input
                        itemNameField.setText("");
                        itemPriceField.setText(""); // Clear price field if invalid item ID
                    }
                } else {
                    // Clear itemNameField and disable it if a non-digit key is pressed
                    itemNameField.setText("");
                    itemPriceField.setText(""); // Clear price field if non-digit key is pressed
                }
            }
        });


        // Edit Button Action Listener
        editButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the index of the selected row
                int selectedRow = table.getSelectedRow();

                // Check if a row is selected
                if(selectedRow == -1) {
                    JOptionPane.showMessageDialog(null, "Please select an item to edit.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Enable confirm button and disable edit button
                confirmButton.setEnabled(true);
                editButton.setEnabled(false);
                addButton.setEnabled(false);
                removeButton.setEnabled(false);
                table.setEnabled(false);

                // Get data from the selected row
                oldItemId = (int) tableModel.getValueAt(selectedRow, 0);
                int itemId = (int) tableModel.getValueAt(selectedRow, 0);
                String itemName = (String) tableModel.getValueAt(selectedRow, 1);
                String quantity = String.valueOf(tableModel.getValueAt(selectedRow, 2));

                // Populate fields with data from the selected row
                itemIdField.setText(String.valueOf(itemId));
                itemNameField.setText(itemName);
                quantityField.setText(quantity);

                // enable fields that should be
                itemIdField.setEnabled(true);
                quantityField.setEnabled(true);
                itemPriceField.setEnabled(true);
            }
        });

        confirmButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                
                int newitemID = 0;
                    try {
                        newitemID = Integer.parseInt(itemIdField.getText().trim());
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(null, "Invalid Item ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
        
                    // Check if item ID exists in the product_size table
                    if (!isValidItemID(newitemID)) {
                        JOptionPane.showMessageDialog(null, "Invalid Item ID.", "Error", JOptionPane.ERROR_MESSAGE);
                        itemIdField.setText(""); // Clear the item ID field
                        return;
                    }

                    String quantity = quantityField.getText().trim();
        
                    // Check if quantity is a positive integer
                    if (!isValidQuantity(quantity)) {
                        JOptionPane.showMessageDialog(null, "Invalid Quantity. Quantity must be a positive integer.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
        
                                        // Get the item price from the database or from the user
                                        double price = Double.parseDouble(itemPriceField.getText().trim());
                                        try {
                                            if (price <= 0) {
                                                JOptionPane.showMessageDialog(null, "Invalid Price. Price must be a positive number.", "Error", JOptionPane.ERROR_MESSAGE);
                                                return;
                                            }
                                        } catch (NumberFormatException ex) {
                                            JOptionPane.showMessageDialog(null, "Invalid Price. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                                            return;
                                        }
        
                    // Calculate subtotal based on the price of the item
                    int qty = Integer.parseInt(quantity);
                    double subtotal = price * qty;
        
                    // Add the item to the database
                    if (updateItemToDatabase(orderID, oldItemId, newitemID, qty, price, subtotal)) {
                        
                        
                        // Clear item ID and quantity fields
                        itemIdField.setText("");
                        itemPriceField.setText("");
                        itemNameField.setText("");
                        quantityField.setText("");

                        setFieldsAndButtonsEnabled(false, itemIdField, itemPriceField, itemNameField, quantityField);

                        // Enable/disable buttons and fields
                        confirmButton.setEnabled(false);
                        editButton.setEnabled(true);
                        addButton.setEnabled(true);
                        removeButton.setEnabled(true);
                        table.setEnabled(true);
                    }

                    updateTable(tableModel, orderID);
            }
        });

        // Close Button ActionListener
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Reset all fields to their initial values
                itemIdField.setText("");
                itemNameField.setText("");
                quantityField.setText("");
                itemPriceField.setText("");

                // Check if in "Save" mode for the add button
                if (saveMode) {
                    // Reset add button to initial state
                    addButton.setBackground(UIManager.getColor("Button.background"));
                    addButton.setText("Add");
                    setFieldsAndButtonsEnabled(false, itemIdField, quantityField, itemPriceField);
                    saveMode = false;
                }
                
                // Enable/disable buttons and fields as needed
                confirmButton.setEnabled(false);
                editButton.setEnabled(true);
                addButton.setEnabled(true);
                removeButton.setEnabled(true);
                table.setEnabled(true);

                itemIdField.setEnabled(false);
                quantityField.setEnabled(false);
                
                // Unlock the table
                table.setEnabled(true);
            }
        });

        // Add a WindowListener to the frame
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Handle the closing event here
                int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to close the program?", "Confirm Close", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    
                    frame.dispose();
                }
            }
        });
    } 

    

    public boolean updateItemToDatabase(int orderID, int oldItemId, int newItemId, int quantity, double price, double subtotal) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;
    
        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
    
            // Check if old and new item IDs are the same
            if (oldItemId == newItemId) {
                // If they are the same, perform a normal update
                System.out.println("Updating item with same ID...");
                String sql = "UPDATE tbl_item SET Item_Quantity = ?, Item_Price = ?, Item_Subtotal = ? WHERE Order_ID = ? AND Item_ID = ?";
                preparedStatement = connection.prepareStatement(sql);
                preparedStatement.setInt(1, quantity);
                preparedStatement.setDouble(2, price);
                preparedStatement.setDouble(3, subtotal);
                preparedStatement.setInt(4, orderID);
                preparedStatement.setInt(5, oldItemId);
    
                // Execute the update
                int rowsAffected = preparedStatement.executeUpdate();
    
                // Check if update was successful
                if (rowsAffected > 0) {
                    success = true;
                    System.out.println("Item updated successfully.");
                } else {
                    System.out.println("Failed to update item.");
                }
            } else {
                // If they are different, first delete the old item
                System.out.println("Deleting old item...");
                String deleteSql = "DELETE FROM tbl_item WHERE Order_ID = ? AND Item_ID = ?";
                preparedStatement = connection.prepareStatement(deleteSql);
                preparedStatement.setInt(1, orderID);
                preparedStatement.setInt(2, oldItemId);
    
                // Execute the deletion
                int rowsAffected = preparedStatement.executeUpdate();
    
                // Check if deletion was successful
                if (rowsAffected > 0) {
                    System.out.println("Old item deleted successfully.");
                    
                    // If deletion was successful, add the new item
                    System.out.println("Adding new item...");
                    String insertSql = "INSERT INTO tbl_item (Item_ID, Order_ID, Item_Quantity, Item_Price, Item_Subtotal) VALUES (?, ?, ?, ?, ?)";
                    preparedStatement = connection.prepareStatement(insertSql);
                    preparedStatement.setInt(1, newItemId);
                    preparedStatement.setInt(2, orderID);
                    preparedStatement.setInt(3, quantity);
                    preparedStatement.setDouble(4, price);
                    preparedStatement.setDouble(5, subtotal);
    
                    // Execute the insertion
                    int insertRowsAffected = preparedStatement.executeUpdate();
    
                    // Check if insertion was successful
                    if (insertRowsAffected > 0) {
                        success = true;
                        System.out.println("Item added successfully.");
                    } else {
                        System.out.println("Failed to add new item.");
                    }
                } else {
                    System.out.println("Failed to delete old item.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error updating item in database: " + e.getMessage());
        } finally {
            // Close JDBC resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    
        return success;
    }
    
    
    

    public boolean checkDuplicateItem(int orderID, int itemID) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean duplicateExists = false;
    
        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
    
            // Prepare SQL statement to check if the item exists in the order
            String sql = "SELECT COUNT(*) AS count FROM tbl_item WHERE Order_ID = ? AND Item_ID = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderID);
            preparedStatement.setInt(2, itemID);
    
            // Execute query
            resultSet = preparedStatement.executeQuery();
    
            // Check if result set has any rows
            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                duplicateExists = (count > 0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error checking duplicate item: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    
        return duplicateExists;
    }

    // Method to fetch data and populate the table
    public void fetchData(int orderID, DefaultTableModel tableModel) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
    
        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
    
            // Prepare SQL statement to fetch data
            String sql = "SELECT tbl_item.Item_ID, tbl_product_size.Item_Name, tbl_item.Item_Quantity, tbl_item.Item_Price, tbl_item.Item_Subtotal " +
                        "FROM tbl_item " +
                        "INNER JOIN tbl_product_size ON tbl_item.Item_ID = tbl_product_size.Item_ID " +
                        "WHERE tbl_item.Order_ID = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderID);
    
            // Execute query
            resultSet = preparedStatement.executeQuery();
    
            // Clear existing data in the table model
            tableModel.setRowCount(0);
    
            // Iterate through the result set and add rows to the table model
            while (resultSet.next()) {
                Object[] rowData = {
                    resultSet.getInt("Item_ID"),
                    resultSet.getString("Item_Name"),
                    resultSet.getInt("Item_Quantity"),
                    resultSet.getInt("Item_Price"),
                    resultSet.getFloat("Item_Subtotal")
                };
                tableModel.addRow(rowData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void updateTable(DefaultTableModel tableModel, int orderID) {
        // Fetch data and populate the table
        fetchData(orderID, tableModel);
        updateOrderTable(orderID);
    }

    public void updateOrderTable(int orderID) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
    
        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
    
            // Prepare SQL statement to calculate total of subtotals
            String sql = "SELECT SUM(Item_Subtotal) AS total FROM tbl_item WHERE Order_ID = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderID);
    
            // Execute query
            ResultSet resultSet = preparedStatement.executeQuery();
    
            // If result set has data, retrieve total of subtotals
            if (resultSet.next()) {
                double totalSubtotal = resultSet.getDouble("total");
    
                // Update Order_TotalPrice in tbl_order
                String updateSql = "UPDATE tbl_order SET Order_TotalPrice = ? WHERE Order_ID = ?";
                PreparedStatement updateStatement = connection.prepareStatement(updateSql);
                updateStatement.setDouble(1, totalSubtotal);
                updateStatement.setInt(2, orderID);
    
                // Execute the update
                int rowsAffected = updateStatement.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Order_TotalPrice updated successfully.");
                } else {
                    System.out.println("Failed to update Order_TotalPrice.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating Order_TotalPrice: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // Method to delete an item from the database based on the Item ID
    public void deleteItemFromDatabase(int itemIdToRemove) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");

            // Prepare SQL statement to delete the item
            String sql = "DELETE FROM tbl_item WHERE Item_ID = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, itemIdToRemove);

            // Execute the deletion
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Item with Item ID " + itemIdToRemove + " deleted successfully from the database.");
            } else {
                System.out.println("No item found with Item ID " + itemIdToRemove + " in the database.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error deleting item from the database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }


    // Method to add an item to the database
    public boolean addItemToDatabase(int orderID, int itemId, String itemName, int quantity, double price, double subtotal) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        boolean success = false;

        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");

            // Prepare SQL statement to insert the item into the database
            String sql = "INSERT INTO TBL_item (Item_ID, Order_ID, Item_Quantity, Item_Price, Item_Subtotal) VALUES (?, ?, ?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, itemId);
            preparedStatement.setInt(2, orderID);
            preparedStatement.setInt(3, quantity);
            preparedStatement.setDouble(4, price);
            preparedStatement.setDouble(5, subtotal);

            // Execute the update
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                success = true;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error adding item to database: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return success;
    }
    
    public static void setFieldsAndButtonsEnabled(boolean enabled, JTextField... fields) {
        for (JTextField field : fields) {
            field.setEnabled(enabled);
        }
    }
    
    public void setButtonsEnabled(boolean enabled, JButton... buttons) {
        for (JButton button : buttons) {
            button.setEnabled(enabled);
        }
    }

    // Method to check if the quantity is a positive integer
    private boolean isValidQuantity(String quantity) {
        return Pattern.matches("\\d+", quantity) && Integer.parseInt(quantity) > 0;
    }

    // Method to check if the item ID exists in the product_size table
    private boolean isValidItemID(int itemId) {
        return order.verifyItemID(itemId);
    }

    // Method to fetch item price from database
    public double fetchItemPrice(int itemId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        double price = 0.0;

        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");

            // Prepare SQL statement to fetch item price
            String sql = "SELECT Item_Price FROM tbl_product_size WHERE Item_ID = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, itemId);

            // Execute query
            resultSet = preparedStatement.executeQuery();

            // If result set has data, retrieve item price
            if (resultSet.next()) {
                price = resultSet.getDouble("Item_Price");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching item price: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return price;
    }
    
}
