import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

class SalesReportViewInterface extends JFrame {
    private JTable table;
    private JLabel totalLabel;
    private JComboBox<String> filterComboBox;

    public SalesReportViewInterface() {
        setTitle("Sales Report");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);

        table = new JTable();
        totalLabel = new JLabel();
        filterComboBox = new JComboBox<>(new String[]{"All", "Month", "Today"});
        filterComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                applyFilter();
            }
        });

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new Dimension(600, 300));

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);
        panel.add(filterComboBox, BorderLayout.NORTH);
        panel.add(totalLabel, BorderLayout.SOUTH);

        add(panel);

        setVisible(true);
        applyFilter();
    }

    private void applyFilter() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
            String query = "SELECT * FROM SalesReportView";
            
            if (filterComboBox.getSelectedItem().equals("Month")) {
                query += " WHERE MONTH(orderDate) = MONTH(CURRENT_DATE()) AND YEAR(orderDate) = YEAR(CURRENT_DATE())";
            } else if (filterComboBox.getSelectedItem().equals("Today")) {
                query += " WHERE DATE(orderDate) = CURDATE()";
            }
            
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("OrderID");
            model.addColumn("orderDate");
            model.addColumn("CustomerName");
            model.addColumn("EmployeeName");
            model.addColumn("TotalAmount");

            double totalAmount = 0;

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("OrderID"),
                        rs.getDate("orderDate"),
                        rs.getString("CustomerName"),
                        rs.getString("EmployeeName"),
                        rs.getDouble("TotalAmount")
                });
                totalAmount += rs.getDouble("TotalAmount");
            }

            table.setModel(model);
            totalLabel.setText("Total Sales: " + totalAmount);

            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SalesReportViewInterface::new);
    }
}
