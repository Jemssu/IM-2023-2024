import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Order {
    
    private boolean isThereAnyOrder;

    // Constructor
    public Order() {
        this.isThereAnyOrder = false;
    }

    // Method to establish connection to MySQL server
    private Connection connect() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/prj_tan";
        String username = "root";
        String password = ""; 
        return DriverManager.getConnection(url, username, password);
    }

    /**
     * This method is called to check if there is any order
     * @return true if there is an order, false otherwise
     */
    public boolean isThereAnyOrder() {
        return isThereAnyOrder;
    }

    public int addOrder(int employee_ID, int customer_ID, String order_Status, double order_TotalPrice) {
        int generatedOrderID = 0;
        try (Connection conn = connect()) {
            // Get current date and time
            Date currentDate = new Date();
            
            // Format the date string
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String order_Date = dateFormat.format(currentDate);

            // Prepare SQL statement
            String sql = "INSERT INTO tbl_order (Employee_ID, Customer_ID, Order_Date, Order_Status, Order_TotalPrice) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            pstmt.setInt(1, employee_ID);
            pstmt.setInt(2, customer_ID);
            pstmt.setString(3, order_Date);
            pstmt.setString(4, order_Status);
            pstmt.setDouble(5, order_TotalPrice);
            pstmt.executeUpdate();

            // Get the generated Order_ID
            ResultSet generatedKeys = pstmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                generatedOrderID = generatedKeys.getInt(1);
            }

            // Set the isThereAnyOrder flag to true
            isThereAnyOrder = true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return generatedOrderID;
    }
    
    public int getOrderID() {
        int latestOrderID = 0;
        try (Connection conn = connect()) {
            String sql = "SELECT Order_ID FROM tbl_order ORDER BY Order_Date DESC LIMIT 1";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            if (rs.next()) {
                latestOrderID = rs.getInt("Order_ID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return latestOrderID;
    }

    // In the Order class

    // Method to update order total in tbl_order table
    public void updateOrderTotal(int orderID, double totalSum) {
        try (Connection conn = connect()) {
            // Update order total in tbl_order
            String updateTotalSQL = "UPDATE tbl_order SET Order_TotalPrice = ? WHERE Order_ID = ?";
            PreparedStatement updateTotalStmt = conn.prepareStatement(updateTotalSQL);
            updateTotalStmt.setDouble(1, totalSum);
            updateTotalStmt.setInt(2, orderID);
            updateTotalStmt.executeUpdate();
            System.out.println("Order total updated successfully for Order ID: " + orderID);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Method to add items to any order
    public void addItem(int orderID, int item_ID, int item_Quantity) {
        try (Connection conn = connect()) {
            // Get item price from tbl_product_size
            String getPriceSQL = "SELECT Item_Price FROM tbl_product_size WHERE item_ID = ?";
            PreparedStatement getPriceStmt = conn.prepareStatement(getPriceSQL);
            getPriceStmt.setInt(1, item_ID);
            ResultSet priceResult = getPriceStmt.executeQuery();
            
            double itemPrice = 0;
            if (priceResult.next()) {
                itemPrice = priceResult.getDouble("Item_Price");
            }
            
            // Calculate item subtotal
            double itemSubtotal = itemPrice * item_Quantity;

            // Insert item into tbl_item
            String insertItemSQL = "INSERT INTO tbl_item (Order_ID, Item_ID, Item_Quantity, Item_Price, Item_Subtotal) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertItemStmt = conn.prepareStatement(insertItemSQL);
            insertItemStmt.setInt(1, orderID);
            insertItemStmt.setInt(2, item_ID);
            insertItemStmt.setInt(3, item_Quantity);
            insertItemStmt.setDouble(4, itemPrice);
            insertItemStmt.setDouble(5, itemSubtotal);
            insertItemStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to add items to any order
    public void addItem(int orderID, int item_ID, int item_Quantity, double itemPrice) {
        try (Connection conn = connect()) {
            // Calculate item subtotal
            double itemSubtotal = itemPrice * item_Quantity;

            // Insert item into tbl_item
            String insertItemSQL = "INSERT INTO tbl_item (Order_ID, Item_ID, Item_Quantity, Item_Price, Item_Subtotal) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertItemStmt = conn.prepareStatement(insertItemSQL);
            insertItemStmt.setInt(1, orderID);
            insertItemStmt.setInt(2, item_ID);
            insertItemStmt.setInt(3, item_Quantity);
            insertItemStmt.setDouble(4, itemPrice);
            insertItemStmt.setDouble(5, itemSubtotal);
            insertItemStmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Method to calculate subtotal price of an item
    public double getSubTotalPrice(int item_ID, int item_Quantity) {
        double itemPrice = 0;
        try (Connection conn = connect()) {
            String sql = "SELECT Item_Price FROM tbl_product_size WHERE item_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, item_ID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                itemPrice = rs.getDouble("Item_Price");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return itemPrice * item_Quantity;
    }

    // Method to remove items from any order
    public void removeItem(int orderID, int item_ID, int item_Quantity) {
        try (Connection conn = connect()) {
            String sql = "DELETE FROM tbl_item WHERE Order_ID = ? AND Item_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, orderID);
            pstmt.setInt(2, item_ID);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void completeOrder(int orderID) {
        try (Connection conn = connect()) {
            // Calculate the total price of all items in the order
            double total = 0;
            String sql = "SELECT Item_Subtotal FROM tbl_item WHERE Order_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, orderID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                total += rs.getDouble("Item_Subtotal");
            }
            
            // Update the total price of the order
            String updateTotalSQL = "UPDATE tbl_order SET Order_TotalPrice = ? WHERE Order_ID = ?";
            PreparedStatement updateTotalStmt = conn.prepareStatement(updateTotalSQL);
            updateTotalStmt.setDouble(1, total);
            updateTotalStmt.setInt(2, orderID);
            updateTotalStmt.executeUpdate();
            
            // Set the isThereAnyOrder flag to false
            isThereAnyOrder = false;
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double getItemPrice(int itemID) {
        double itemPrice = 0;
        try (Connection conn = connect()) {
            String sql = "SELECT Item_Price FROM tbl_product_size WHERE item_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, itemID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                itemPrice = rs.getDouble("Item_Price");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return itemPrice;
    }

    // Method to verify if item ID exists in tbl_product_size
    public boolean verifyItemID(int itemID) {
        try (Connection conn = connect()) {
            String sql = "SELECT * FROM tbl_product_size WHERE item_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, itemID);
            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // Returns true if item ID exists, false otherwise
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false; // Return false in case of an exception or if the item ID doesn't exist
    }

    // Method to cancel an order
    public boolean cancelOrder(int orderId) {
        try (Connection conn = connect()) {
            // Prepare SQL statement to update the order status to "Canceled"
            String sql = "UPDATE tbl_order SET status = 'Canceled' WHERE order_id = ?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, orderId);

            // Execute the update
            int rowsAffected = statement.executeUpdate();

            // Check if the update was successful
            if (rowsAffected > 0) {
                System.out.println("Order with ID " + orderId + " canceled successfully.");
                return true;
            } else {
                System.out.println("Failed to cancel the order.");
                return false;
            }
        } catch (SQLException e) {
            // Handle database errors
            e.printStackTrace();
            return false;
        }
    }

    // Method to fully delete an order
    public boolean deleteOrder(int orderId) {
        try (Connection conn = connect()) {
            // Delete associated items first
            String deleteItemsSQL = "DELETE FROM tbl_item WHERE Order_ID = ?";
            PreparedStatement deleteItemsStatement = conn.prepareStatement(deleteItemsSQL);
            deleteItemsStatement.setInt(1, orderId);
            deleteItemsStatement.executeUpdate();
    
            // Now delete the order
            String deleteOrderSQL = "DELETE FROM tbl_order WHERE order_id = ?";
            PreparedStatement deleteOrderStatement = conn.prepareStatement(deleteOrderSQL);
            deleteOrderStatement.setInt(1, orderId);
    
            // Execute the delete statement
            int rowsAffected = deleteOrderStatement.executeUpdate();
    
            if (rowsAffected > 0) {
                System.out.println("Order with ID " + orderId + " deleted successfully.");
                return true;
            } else {
                System.out.println("Failed to delete the order.");
                return false;
            }
        } catch (SQLException e) {
            // Handle database errors
            e.printStackTrace();
            return false;
        }
    }
    

    //Method to get the orderStatus from the order
    public String getOrderStatus(int orderID) {
        String orderStatus = "";
        try (Connection conn = connect()) {
            String sql = "SELECT Order_Status FROM tbl_order WHERE Order_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, orderID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                orderStatus = rs.getString("Order_Status");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderStatus;
    }

    public String getEmployeeName(int employee_ID) { 
        String employeeName = "";
        try (Connection conn = connect()) {
            String sql = "SELECT employee_FirstName, employee_LastName FROM tbl_employee WHERE employee_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, employee_ID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String firstName = rs.getString("employee_FirstName");
                String lastName = rs.getString("employee_LastName");
                employeeName = firstName + " " + lastName;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return employeeName;
    }

    public String getContactNumber(long ID) {
        String customerNumber = "-1"; // Initialize to "-1" indicating customer not found
        try (Connection conn = connect()) {
            String sql = "SELECT Customer_ContactNum FROM tbl_customer WHERE customer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setLong(1, ID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // Retrieve the contact number as a string
                customerNumber = rs.getString("Customer_ContactNum");
                // Ensure it has 11 digits and starts with '0'
                customerNumber = String.format("%011d", Long.parseLong(customerNumber));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return customerNumber;
    }

    public String getItemName(int ID) {
        String itemName = ""; 
        try (Connection conn = connect()) {
            String sql = "SELECT Item_Name FROM tbl_product_size WHERE item_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setLong(1, ID);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // Retrieve the contact number as a string
                itemName = rs.getString("Item_Name");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return itemName;
    }

    
}