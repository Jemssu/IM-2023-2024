import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class CustomerEditUI {

    // Text fields
    private static JTextField firstNameTextField;
    private static JTextField lastNameTextField;
    private static JTextField contactNumberTextField;
    private static JTextField customerIdTextField;
    private static JTextField searchField;

    // Buttons
    private static JButton searchButton;
    private static JButton createButton;
    private static JButton updateButton;
    private static JButton deleteButton;
    private static JButton confirmButton;

    // Method to check if a string contains any numeric characters
    public static boolean containsNumeric(String str) {
        for (char c : str.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    // Method to clear all text fields
    private static void clearFields() {
        firstNameTextField.setText("");
        lastNameTextField.setText("");
        contactNumberTextField.setText("");
        customerIdTextField.setText("");
    }

    // Method to enable or disable text fields
    private static void setFieldsEnabled(boolean enabled) {
        firstNameTextField.setEnabled(enabled);
        lastNameTextField.setEnabled(enabled);
        contactNumberTextField.setEnabled(enabled);

    }

    // Method to enable or disable buttons
    private static void setButtonsEnabled(boolean enabled) {
        searchButton.setEnabled(enabled);
        createButton.setEnabled(enabled);
        updateButton.setEnabled(enabled);
        deleteButton.setEnabled(enabled);
        confirmButton.setEnabled(false);
    }


    // Method to reset buttons and fields to their default state
    private static void resetButtonsAndFields() {
        // Reset buttons
        createButton.setText("CREATE");
        createButton.setBackground(UIManager.getColor("Button.background"));
        setButtonsEnabled(true);

        // Reset fields
        clearFields();
        setFieldsEnabled(false);
    }

    public static void main(String[] args) {
        openEditUI();
    }

    public static void openEditUI() {
        // Create JFrame
        JFrame frame = new JFrame("Edit Customer Details (LARGE PANEL)");
        frame.setSize(850, 420); // Set frame size
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null); // Use absolute positioning

        // Create Customer object
        Customer customer = new Customer();

        // TITLE HEADER THINGY
        JLabel header = new JLabel("Customer ID:");
        header.setBounds(20, 20, 250, 20);
        frame.add(header);
        header.setFont(new Font("Arial", Font.BOLD, 14));

        customerIdTextField = new JTextField();
        customerIdTextField.setBounds(130, 20, 200, 20);
        customerIdTextField.setEditable(false); // Make it read-only
        frame.add(customerIdTextField);

        // Create Customer Panel
        JPanel customerPanel = new JPanel();
        customerPanel.setBorder(BorderFactory.createTitledBorder("Customer Details"));
        customerPanel.setLayout(null);
        customerPanel.setBounds(10, 50, 350, 100);

        frame.add(customerPanel);

        // Customer First Name Label and TextField
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(20, 20, 150, 20);
        customerPanel.add(firstNameLabel);
        firstNameLabel.setFont(new Font("Arial", Font.BOLD, 14));

        firstNameTextField = new JTextField();
        firstNameTextField.setBounds(120, 20, 200, 20);
        customerPanel.add(firstNameTextField);

        // Customer Last Name Label and TextField
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(20, 42, 150, 20);
        customerPanel.add(lastNameLabel);
        lastNameLabel.setFont(new Font("Arial", Font.BOLD, 14));

        lastNameTextField = new JTextField();
        lastNameTextField.setBounds(120, 42, 200, 20);
        customerPanel.add(lastNameTextField);
        lastNameTextField.setFont(new Font("Arial", Font.PLAIN, 12));

        // Contact Number Label and TextField
        JLabel contactNumberLabel = new JLabel("Contact #:");
        contactNumberLabel.setBounds(20, 64, 150, 20);
        customerPanel.add(contactNumberLabel);
        contactNumberLabel.setFont(new Font("Arial", Font.BOLD, 14));

        contactNumberTextField = new JTextField();
        contactNumberTextField.setBounds(120, 64, 200, 20);
        customerPanel.add(contactNumberTextField);
        contactNumberTextField.setFont(new Font("Arial", Font.PLAIN, 12));

        // Create Operation Panel
        JPanel operPanel = new JPanel();
        operPanel.setBorder(BorderFactory.createTitledBorder("Operation Buttons"));
        operPanel.setLayout(new GridLayout(5, 1));
        operPanel.setBounds(10, 160, 350, 200);

        frame.add(operPanel);

        // Create Button
        createButton = new JButton("CREATE");
        operPanel.add(createButton);

        // Clear Button
        confirmButton = new JButton("CONFIRM");
        operPanel.add(confirmButton);

        // Update Button
        updateButton = new JButton("UPDATE");
        operPanel.add(updateButton);

        // Delete Button
        deleteButton = new JButton("DELETE");
        operPanel.add(deleteButton);

        // Cancel Button
        JButton cancelButton = new JButton("CANCEL");
        operPanel.add(cancelButton);

        // Search Field and Button
        searchField = new JTextField();
        searchField.setBounds(400, 10, 200, 20);
        frame.add(searchField);

        searchButton = new JButton("Search");
        searchButton.setBounds(610, 10, 100, 20);
        frame.add(searchButton);

        // JTable to display customer data
        JTable table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells non-editable
                return false;
            }
        };
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(400, 40, 400, 320);
        frame.add(scrollPane);

        // Fetch data from database and populate the table
        try {
            // JDBC URL and credentials
            String url = "jdbc:mysql://localhost:3306/prj_tan";
            String username = "root";
            String password = "";

            // Create database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to fetch all records from tbl_customer
            String query = "SELECT * FROM tbl_customer";

            // Create statement
            Statement statement = connection.createStatement();

            // Execute query
            ResultSet resultSet = statement.executeQuery(query);

            // Create DefaultTableModel to store fetched data
            DefaultTableModel model = new DefaultTableModel();
            table.setModel(model);

            // Add columns to the model
            model.addColumn("Customer ID");
            model.addColumn("First Name");
            model.addColumn("Last Name");
            model.addColumn("Contact Number");

            // Populate the model with data from the ResultSet
            while (resultSet.next()) {
                Object[] row = {
                        resultSet.getInt("Customer_ID"),
                        resultSet.getString("Customer_FirstName"),
                        resultSet.getString("Customer_LastName"),
                        resultSet.getString("Customer_ContactNum")
                };
                model.addRow(row);
            }

            // Close resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to fetch data from the database!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        resetButtonsAndFields();

        createButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (createButton.getText().equals("CREATE")) {
                    // Lock the table
                    table.setEnabled(false);
                    // Clear text fields
                    clearFields();
        
                    // Enable text fields
                    setFieldsEnabled(true);
        
                    // Disable other buttons
                    setButtonsEnabled(false);
                    createButton.setEnabled(true);
        
                    // Change CREATE button to SAVE
                    createButton.setBackground(Color.GREEN);
                    createButton.setText("SAVE");
                } else if (createButton.getText().equals("SAVE")) {
                    // Unlock the table
                    table.setEnabled(true);
                    // Get first name, last name, and contact number from text fields
                    String firstName = firstNameTextField.getText();
                    String lastName = lastNameTextField.getText();
                    String contactNumber = contactNumberTextField.getText();
        
                    // Check if all fields are filled up
                    if (firstName.isEmpty() || lastName.isEmpty() || contactNumber.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Please fill up all fields!");
                        return;
                    }
        
                    // Check if first name and last name contain only letters
                    if (!firstName.matches("[a-zA-Z]+") || !lastName.matches("[a-zA-Z]+")) {
                        JOptionPane.showMessageDialog(frame, "First name and last name should contain only letters!");
                        return;
                    }
        
                    // Check if first name and last name contain only letters
                    if (!contactNumber.matches("\\d{11}")) {
                        JOptionPane.showMessageDialog(frame, "Contact number must be 11 digits!");
                        return;
                    }
        
                    // Check if the customer exists
                    if (customer.doesCustomerExist(firstName, lastName)) {
                        JOptionPane.showMessageDialog(frame, "Customer already exists!");
                        return;
                    }
        
                    // After adding a new customer successfully, call the updateTable method
                    if (customer.addCustomer(firstName, lastName, contactNumber)) {
                        // Display prompt if customer is added successfully
                        JOptionPane.showMessageDialog(frame, "Customer added successfully!");
        
                        // Update the table with the latest data
                        updateTable(table, frame);
        
                        // Reset buttons and fields
                        resetButtonsAndFields();


                        table.setEnabled(true);
                    } else {
                        JOptionPane.showMessageDialog(frame, "Failed to add customer!", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });
        

        // Delete Button ActionListener
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the selected row index
                int selectedRow = table.getSelectedRow();

                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "Please select a row to delete.", "No Row Selected", JOptionPane.WARNING_MESSAGE);
                } else {
                    int confirmDelete = JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete this record?\n\n" +
                            "Customer ID: " + table.getValueAt(selectedRow, 0) + "\n" +
                            "First Name: " + table.getValueAt(selectedRow, 1) + "\n" +
                            "Last Name: " + table.getValueAt(selectedRow, 2) + "\n" +
                            "Contact Number: " + table.getValueAt(selectedRow, 3), "Confirm Deletion", JOptionPane.YES_NO_OPTION);

                    if (confirmDelete == JOptionPane.YES_OPTION) {
                        // Ask for password
                        String password = JOptionPane.showInputDialog(frame, "Enter password to proceed with deletion:");

                        if (password != null && password.equals("1111")) {
                            // Get the customer ID of the selected row
                            String customerId = table.getValueAt(selectedRow, 0).toString();

                            // Convert customer ID to integer
                            int customerIdInt = Integer.parseInt(customerId);

                            // Perform deletion
                            if (customer.deleteCustomer(customerIdInt)) {
                                // Display prompt if deletion is successful
                                JOptionPane.showMessageDialog(frame, "Record deleted successfully!");

                                // Update the table with the latest data
                                updateTable(table, frame);
                            } else {
                                JOptionPane.showMessageDialog(frame, "Failed to delete record.", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(frame, "Incorrect password. Deletion cancelled.", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    }
                }
            }
        });

        // Search Button ActionListener
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the search text from the search field
                String searchText = searchField.getText().trim();

                // Get the table model
                DefaultTableModel model = (DefaultTableModel) table.getModel();

                // Create a row sorter for the table
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                table.setRowSorter(sorter);

                // Apply a filter based on the search text
                if (searchText.length() == 0) {
                    // If the search text is empty, remove any existing filter
                    sorter.setRowFilter(null);
                } else {
                    // Apply a regex filter to match the search text
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText)); // (?i) makes the search case-insensitive
                }
            }
        });

        // Update Button ActionListener
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Check if a row is selected
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "Please select a row to update.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Get the selected customer's details
                int customerID = (int) table.getValueAt(selectedRow, 0);
                String firstName = (String) table.getValueAt(selectedRow, 1);
                String lastName = (String) table.getValueAt(selectedRow, 2);
                String contactNumber = (String) table.getValueAt(selectedRow, 3);

                // Populate the text fields with the selected customer's details
                customerIdTextField.setText(String.valueOf(customerID));
                firstNameTextField.setText(firstName);
                lastNameTextField.setText(lastName);
                contactNumberTextField.setText(contactNumber);

                // Enable text fields for editing
                setFieldsEnabled(true);

                // Disable other buttons
                setButtonsEnabled(false);
                updateTable(table, frame);
                // Unlock the table
                table.setEnabled(false);

                // Enable Confirm button
                confirmButton.setEnabled(true);
            }
        });

        // Confirm Button ActionListener
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get data from text fields
                int customerID = Integer.parseInt(customerIdTextField.getText());
                String newFirstName = firstNameTextField.getText();
                String newLastName = lastNameTextField.getText();
                String newContactNumber = contactNumberTextField.getText();

                // Validate input
                if (!newFirstName.matches("[a-zA-Z]+") || !newLastName.matches("[a-zA-Z]+")) {
                    JOptionPane.showMessageDialog(frame, "First name and last name should contain only letters!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (!newContactNumber.matches("\\d{11}")) {
                    JOptionPane.showMessageDialog(frame, "Contact number must be 11 digits!", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Update customer details
                customer.updateCustomer(customerID, newFirstName, newLastName, newContactNumber);

                // Reset fields and buttons
                resetButtonsAndFields();
                updateTable(table, frame);
                // Unlock the table
                table.setEnabled(true);

                // Disable Confirm button
                confirmButton.setEnabled(false);
            }
        });

        // Close Button ActionListener
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetButtonsAndFields();
                // Unlock the table
                table.setEnabled(true);
            }
        });

        // Add a ListSelectionListener to the table
        ListSelectionModel selectionModel = table.getSelectionModel();
        selectionModel.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Check if the selection is not adjusting
                if (!e.getValueIsAdjusting()) {
                    // Get the selected row index
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) { // If a row is selected
                        // Get data from the selected row
                        String customerId = table.getValueAt(selectedRow, 0).toString();
                        String firstName = table.getValueAt(selectedRow, 1).toString();
                        String lastName = table.getValueAt(selectedRow, 2).toString();
                        String contactNumber = table.getValueAt(selectedRow, 3).toString();

                        // Set data to text fields
                        customerIdTextField.setText(customerId);
                        firstNameTextField.setText(firstName);
                        lastNameTextField.setText(lastName);
                        contactNumberTextField.setText(contactNumber);
                    }
                }
            }
        });

        // Set frame visible
        frame.setVisible(true);
    }


    // Method to update the table with the latest data from the database
    private static void updateTable(JTable table, JFrame frame) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0); // Clear existing rows from the table

        try {
            // JDBC URL, username, and password
            String url = "jdbc:mysql://localhost:3306/prj_tan";
            String username = "root";
            String password = "";

            // Create database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to fetch all records from tbl_customer
            String query = "SELECT * FROM tbl_customer";

            // Create statement
            Statement statement = connection.createStatement();

            // Execute query
            ResultSet resultSet = statement.executeQuery(query);

            // Populate the model with data from the ResultSet
            while (resultSet.next()) {
                String contactNumber = resultSet.getString("Customer_ContactNum");

                // Add leading "0" if the contact number doesn't start with "0"
                if (!contactNumber.startsWith("0")) {
                    contactNumber = "0" + contactNumber;
                }

                Object[] row = {
                        resultSet.getInt("Customer_ID"),
                        resultSet.getString("Customer_FirstName"),
                        resultSet.getString("Customer_LastName"),
                        contactNumber
                };
                model.addRow(row);
            }

            // Close resources
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to fetch data from the database!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
