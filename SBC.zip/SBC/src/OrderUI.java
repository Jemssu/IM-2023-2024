import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

class NonEditableTableModel extends DefaultTableModel {
    @Override
    public boolean isCellEditable(int row, int column) {
        return false; // Disable cell editing
    }
}

public class OrderUI extends JFrame {
    private JTextField moreOrderIDField, moreEmpNameField, moreCNameField, moreCContField, orderIdField, customerIDField, employeeIdField, employeeNameField, firstNameField, lastNameField, customerIdField, contactNoField;
    private JButton createOrderButton, customerAddButton, addButton, newOrderButton, completeOrderButton, cancelOrderButton, customerClearButton, lockcustomerClearButton, toggleCompletedButton;;
    private JPanel mainPanel, customerPanel, itemPanel;
    private JLabel programName;
    private DefaultTableModel orderTableModel;
    private int loggedInEmployeeID;
    private boolean isLocked = false;
    private JTable itemTable, newTbl_order;
    private DefaultTableModel tableModel;
    private Order order = new Order();
    String selectedOption = "ALL";
    private boolean isOrderCreated = false; // Local boolean variable to track if an order is created

    // FONT OBJECTS 
    Font labelFont = new Font("Arial", Font.BOLD, 20);
    Font smallLabel = new Font("Arial", Font.BOLD, 14);
    Font fieldFont = new Font("Arial", Font.PLAIN, 12);


    // Local boolean variable to track the lock status of customer details fields
    private boolean isThereACustomer = false;

    // Method to lock customer details fields
    private void lockCustomerDetailsFields() {
        firstNameField.setEditable(false);
        lastNameField.setEditable(false);
    }

    // Method to unlock customer details fields
    private void unlockCustomerDetailsFields() {
        firstNameField.setEditable(true);
        lastNameField.setEditable(true);
    }

    // Method to validate if a string contains only letters
    private boolean isValidName(String name) {
        return Pattern.matches("[a-zA-Z]+", name);
    }

    // Method to validate if a string is an 11-digit number
    private boolean isValidContactNumber(String contactNumber) {
        return Pattern.matches("\\d{11}", contactNumber);
    }

    public boolean checkDuplicateItem(int orderID, int itemID) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        boolean duplicateExists = false;
    
        try {
            // Establish connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
    
            // Prepare SQL statement to check if the item exists in the order
            String sql = "SELECT COUNT(*) AS count FROM tbl_item WHERE Order_ID = ? AND Item_ID = ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setInt(1, orderID);
            preparedStatement.setInt(2, itemID);
    
            // Execute query
            resultSet = preparedStatement.executeQuery();
    
            // Check if result set has any rows
            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                duplicateExists = (count > 0);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error checking duplicate item: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        } finally {
            // Close JDBC resources
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    
        return duplicateExists;
    }

    public OrderUI(int employeeID) {
        this.loggedInEmployeeID = employeeID;

        setTitle("Stephanie Bolt Center --- Point of Sale System --- by James Nathaniel Tan");
        setSize(1366, 768);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Main Panel
        mainPanel = new JPanel();
        mainPanel.setLayout(null);

        // HEADER LABEL
        JLabel programName = new JLabel("STEPHANIE BOLT CENTER SYSTEM");
        programName.setFont(labelFont);
        programName.setBounds(20, 10, 500, 20);
        mainPanel.add(programName);

        // ORDER ID LABEL AND FIELD
        JLabel orderIdLabel = new JLabel("Order ID:");
        orderIdLabel.setFont(smallLabel);
        orderIdLabel.setBounds(20, 40, 80, 20);
        
        orderIdField = new JTextField() {
            @Override public void setBorder(Border border) {
                // No!
            }
        };
        orderIdField.setFont(fieldFont);
        orderIdField.setBounds(120, 40, 100, 20);
        orderIdField.setEditable(false); // Set as uneditable

        mainPanel.add(orderIdLabel);
        mainPanel.add(orderIdField);

        // CUSTOMER ID LABEL AND FIELD
        JLabel customerIDLabel = new JLabel("Customer ID:");
        customerIDLabel.setFont(smallLabel);
        customerIDLabel.setBounds(20, 60, 130, 20);
        
        customerIDField = new JTextField() {
            @Override public void setBorder(Border border) {
                // No!
            }
        };
        customerIDField.setFont(fieldFont);
        customerIDField.setBounds(120, 61, 100, 20);
        customerIDField.setEditable(false); // Set as uneditable

        mainPanel.add(customerIDLabel);
        mainPanel.add(customerIDField);

        // EMP ID LABEL AND FIELD
        JLabel employeeIdLabel = new JLabel("Employee ID:");
        employeeIdLabel.setBounds(250, 40, 100, 20);
        employeeIdLabel.setFont(smallLabel);

        employeeIdField = new JTextField(String.valueOf(loggedInEmployeeID)) {
            @Override public void setBorder(Border border) {
                // No!
            }
        };
        employeeIdField.setFont(fieldFont);
        employeeIdField.setBounds(375, 41, 100, 20);
        employeeIdField.setEditable(false); // Set as uneditable

        mainPanel.add(employeeIdLabel);
        mainPanel.add(employeeIdField);

        // EMP NAME LABEL AND FIELD
        JLabel employeeNameLabel = new JLabel("Employee Name:");
        employeeNameLabel.setBounds(250, 60, 130, 20);
        employeeNameLabel.setFont(smallLabel);

        employeeNameField = new JTextField(order.getEmployeeName(loggedInEmployeeID)) {
            @Override public void setBorder(Border border) {
                // No!
            }
        };;
        employeeNameField.setFont(fieldFont);
        employeeNameField.setBounds(375, 61, 130, 20);
        employeeNameField.setEditable(false); // Set as uneditable

        mainPanel.add(employeeNameLabel);
        mainPanel.add(employeeNameField);

        /**
         *  CUSTOMER DETAILS PANEL
         *  
         */

        // INITIALIZING THE PANEL HERE
        customerPanel = new JPanel();
        customerPanel.setBorder(BorderFactory.createTitledBorder("Customer Details"));
        customerPanel.setLayout(null);
        customerPanel.setBounds(20, 120, 440, 100);

        // FIRST NAME
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(20, 20, 80, 20);
        firstNameLabel.setFont(smallLabel);

        firstNameField = new JTextField();
        firstNameField.setBounds(120, 20, 100, 20);
        firstNameField.setFont(fieldFont);

        customerPanel.add(firstNameLabel);
        customerPanel.add(firstNameField);

        // LAST NAME
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(20, 42, 100, 20);
        lastNameLabel.setFont(smallLabel);
        lastNameField = new JTextField();
        lastNameField.setBounds(120, 42, 100, 20);
        lastNameField.setFont(fieldFont);

        customerPanel.add(lastNameLabel);
        customerPanel.add(lastNameField);

        // CONTACT NUMBER
        JLabel contactNoLabel = new JLabel("Contact Num:");
        contactNoLabel.setBounds(20, 64, 100, 20);
        contactNoLabel.setFont(smallLabel);

        contactNoField = new JTextField();
        contactNoField.setBounds(120, 64, 100, 20);
        contactNoField.setFont(fieldFont);
        contactNoField.setEditable(false);

        customerPanel.add(contactNoLabel);
        customerPanel.add(contactNoField);

        // CUSTOMER SEARCH BUTTON
        JButton customerSearchButton = new JButton("Search / Add Customer");
        customerSearchButton.setBounds(240, 20, 180, 20);
        customerPanel.add(customerSearchButton);

        // CUSTOMER CLEAR BUTTON
        customerClearButton = new JButton("Clear Customer Details");
        customerClearButton.setBounds(240, 42, 180, 20);
        customerPanel.add(customerClearButton);

        // CUSTOMER EDIT BUTTON
        JButton customerEditButton = new JButton("Edit / Update Customer");
        customerEditButton.setBounds(240, 64, 180, 20);
        customerPanel.add(customerEditButton);

        // ACTION LISTENER FOR CUSTOMER SEARCH / ADD
        customerSearchButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Check the First and Last Name Fields
                String firstName = firstNameField.getText().trim();
                String lastName = lastNameField.getText().trim();

                //Check if Empty
                if (firstName.length() == 0 && lastName.length() == 0) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Please Enter First and Last Name", "Missing Input", JOptionPane.ERROR_MESSAGE);
                    return; 
                }
                
                // Validate the First and Last Names
                if (!isValidName(firstName) || !isValidName(lastName)) {
                    JOptionPane.showMessageDialog(OrderUI.this, "First name and last name must contain only letters.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    return; 
                }

                // Search for the customer in the database
                Customer customer = new Customer();
                int customerID = customer.getCustomerIDIfExists(firstName, lastName);
                
                // If the customer exists
                if (customerID != -1) {
                    // Get their contact number
                    String contactNumber = String.valueOf(order.getContactNumber(customerID));
                    // Populate the contact number field
                    contactNoField.setText(contactNumber);
                    //sets the customerID field
                    customerIDField.setText(String.valueOf(customerID));
                    // Lock all fields
                    lockCustomerDetailsFields();
                    // lock and unlock other buttons
                    customerSearchButton.setEnabled(false);
                    customerEditButton.setEnabled(false);
                    customerClearButton.setEnabled(true);
                    isThereACustomer = true;
                    // Display a message indicating the customer exists
                    JOptionPane.showMessageDialog(OrderUI.this, "Customer already exists. Customer ID: " + customerID + "\nDetails Filled In. " , "Existing Customer", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // Prompt the user to add the contact number
                    String contactNumber = JOptionPane.showInputDialog(OrderUI.this, "Customer not found. Please enter the contact number (11 digits):");
                    // Validate the contact number
                    if (!isValidContactNumber(contactNumber)) {
                        JOptionPane.showMessageDialog(OrderUI.this, "Contact number must be an 11-digit number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                        return; // Stop further processing
                    }
                    // Add the customer to the database
                    if (customer.addCustomer(firstName, lastName, contactNumber)) {
                        // Retrieve their ID
                        customerID = customer.getCustomerIDIfExists(firstName, lastName);

                        //sets the customerID field
                        customerIDField.setText(String.valueOf(customerID));
                        // Populate the contact number field
                        contactNoField.setText(contactNumber);
                        // Lock all fields
                        lockCustomerDetailsFields();
                        // lock and unlock other buttons
                        customerSearchButton.setEnabled(false);
                        customerEditButton.setEnabled(false);
                        customerClearButton.setEnabled(true);
                        isThereACustomer = true;

                        // Display a message indicating the new customer is added
                        JOptionPane.showMessageDialog(OrderUI.this, "New customer added successfully. Customer ID: " + customerID, "New Customer Added", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        // Display an error message if adding the customer fails
                        JOptionPane.showMessageDialog(OrderUI.this, "Failed to add customer.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        });

        // ACTION LISTENER FOR EDIT BUTTON
        // Edit Button ActionListener
        customerEditButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Create a new instance of CustomerEditUI class
                CustomerEditUI customerEditUI = new CustomerEditUI();
                // Call a method in CustomerEditUI class to open the edit UI
                customerEditUI.openEditUI();
            }
        });

        // ACTION LISTENER FOR CLEAR DETAILS
        customerClearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Clear Details
                firstNameField.setText("");
                lastNameField.setText("");
                contactNoField.setText("");

                // Unlock customer details fields
                unlockCustomerDetailsFields();

                // Enable the "SEARCH / ADD BUTTON" button
                customerSearchButton.setEnabled(true);
                customerEditButton.setEnabled(true);

                isThereACustomer = false;
            }
        });

        mainPanel.add(customerPanel);

        /**
         *  ITEM PANEL DETAILS
         */

        // Item Panel
        itemPanel = new JPanel();
        itemPanel.setBorder(BorderFactory.createTitledBorder("Item Details"));
        itemPanel.setLayout(null);
        itemPanel.setBounds(460, 120, 350, 100);

        // Item ID
        JLabel itemIdLabel = new JLabel("Item ID:");
        itemIdLabel.setBounds(20, 20, 80, 20);
        itemIdLabel.setFont(smallLabel);

        JTextField itemIdField = new JTextField();
        itemIdField.setBounds(100, 20, 100, 20);
        itemIdField.setEnabled(false);
        itemIdField.setFont(fieldFont);

        itemPanel.add(itemIdLabel);
        itemPanel.add(itemIdField);

        // Quantity
        JLabel quantityLabel = new JLabel("Quantity:");
        quantityLabel.setBounds(20, 42, 80, 20);
        quantityLabel.setFont(smallLabel);
        
        JTextField quantityField = new JTextField();
        quantityField.setBounds(100, 42, 100, 20);
        quantityField.setEnabled(false);
        quantityField.setFont(fieldFont);

        itemPanel.add(quantityLabel);
        itemPanel.add(quantityField);

        // Item Name
        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setBounds(20, 64, 80, 20);
        itemNameLabel.setFont(smallLabel);
        
        JTextField itemNameField = new JTextField();
        itemNameField.setBounds(100, 64, 230, 20);
        itemNameField.setEnabled(false);
        itemNameField.setFont(fieldFont);

        itemPanel.add(itemNameLabel);
        itemPanel.add(itemNameField);

        // Add Item Button
        addButton = new JButton("Add Item");
        addButton.setBounds(210, 20, 120, 20);
        itemPanel.add(addButton);
        addButton.setEnabled(false);

        // Remove Item Button
        JButton removeButton = new JButton("Remove Item");
        removeButton.setBounds(210, 42, 120, 20);
        itemPanel.add(removeButton);
        removeButton.setEnabled(false);

        // Define a List to temporarily store added items
        List<Integer> addedItemIDs = new ArrayList<>();

        // Add Button Action Listener
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int itemId = 0;
                try {
                    itemId = Integer.parseInt(itemIdField.getText().trim());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Invalid Item ID. Please enter a valid integer.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check if item ID exists in the product_size table
                if (!isValidItemID(itemId)) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Invalid Item ID.", "Error", JOptionPane.ERROR_MESSAGE);
                    itemIdField.setText(""); // Clear the item ID field
                    return;
                }

                String quantity = quantityField.getText().trim();

                // Check if quantity is a positive integer
                if (!isValidQuantity(quantity)) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Invalid Quantity. Quantity must be a positive integer.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check for duplicate item IDs in the temporary list
                if (addedItemIDs.contains(itemId)) {
                    JOptionPane.showMessageDialog(OrderUI.this, "You have already entered this item.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Get the item name corresponding to the item ID
                String itemName = order.getItemName(itemId);

                // Get the item price from the database or from the user
                double price = order.getItemPrice(itemId);
                String itemPriceInput = JOptionPane.showInputDialog(OrderUI.this, "Enter the item price:", price);
                if (itemPriceInput == null) {
                    // User canceled, abort
                    return;
                }
                try {
                    price = Double.parseDouble(itemPriceInput);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Invalid item price. Please enter a valid number.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Calculate subtotal based on the price of the item
                int qty = Integer.parseInt(quantity);
                double subtotal = price * qty;

                // Add the item ID to the temporary list
                addedItemIDs.add(itemId);

                // Add the item to the table along with the item name and price
                tableModel.addRow(new Object[]{itemId, itemName, quantity, price, subtotal});

                // Clear item ID and quantity fields
                itemIdField.setText("");
                itemNameField.setText("");
                quantityField.setText("");
            }
        });



        // Remove Item Button Action Listener
        removeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the index of the selected row
                int selectedRow = itemTable.getSelectedRow();
                
                // Check if a row is selected
                if(selectedRow == -1) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Please select an item to remove.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Prompt the user for confirmation
                int choice = JOptionPane.showConfirmDialog(OrderUI.this, "Are you sure you want to remove this item?", "Confirm Removal", JOptionPane.YES_NO_OPTION);
                
                // If the user confirms removal
                if (choice == JOptionPane.YES_OPTION) {
                    // Remove the selected row from the table
                    tableModel.removeRow(selectedRow);
                    JOptionPane.showMessageDialog(OrderUI.this, "Item removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        // Add KeyListener to itemIdField
        itemIdField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                // Check if the entered key is a number (0-9)
                if (Character.isDigit(e.getKeyChar())) {
                    int itemId = 0;
                    try {
                        itemId = Integer.parseInt(itemIdField.getText().trim());
                        // Call getItemName method to get the item name
                        String itemName = order.getItemName(itemId);
                        if (itemName != null) {
                            // If the item name exists, enable itemNameField and set its text
                            itemNameField.setText(itemName);
                        } else {
                            itemNameField.setText("");
                        }
                    } catch (NumberFormatException ex) {
                        // Handle non-integer input
                        itemNameField.setText("");
                    }
                } else {
                    // Clear itemNameField and disable it if a non-digit key is pressed
                    itemNameField.setText("");
                }
            }
        });


        mainPanel.add(itemPanel);

        
        // Current Order
        JPanel currentPanel = new JPanel();
        currentPanel.setBorder(BorderFactory.createTitledBorder("Current Order"));
        currentPanel.setLayout(null);
        currentPanel.setBounds(20, 220, 790, 260);

        // Initialize table model and table
        tableModel = new DefaultTableModel();
        itemTable = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(itemTable);
        scrollPane.setBounds(20, 20, 750, 200);
        currentPanel.add(scrollPane);

        // Add Table Headers
        tableModel.addColumn("Item ID");
        tableModel.addColumn("Item Name");
        tableModel.addColumn("Quantity");
        tableModel.addColumn("Price");
        tableModel.addColumn("Subtotal");

        // Define a ListSelectionListener for the table
        ListSelectionListener selectionListener = new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                // Check if the selection is adjusting
                if (!e.getValueIsAdjusting()) {
                    // Get the selected row index
                    int selectedRow = itemTable.getSelectedRow();
                    
                    // Enable or disable the Remove Item button based on selection
                    removeButton.setEnabled(selectedRow != -1);
                }
            }
        };

        // Add the ListSelectionListener to the table
        itemTable.getSelectionModel().addListSelectionListener(selectionListener);

        
        // CREATE ORDER BUTTON

        JButton createOrderButton = new JButton("Create a New Order");
        createOrderButton.setBounds(20+40, 225, 200, 20);

        currentPanel.add(createOrderButton);

        // CONFIRM ORDER

        JButton confirmOrderButton = new JButton("Confirm Order");
        confirmOrderButton.setBounds(250+40, 225, 200, 20);

        currentPanel.add(confirmOrderButton);
        confirmOrderButton.setEnabled(false);

        // CANCEL BUTTON

        JButton cancelOrderButton = new JButton("Cancel the Order");
        cancelOrderButton.setBounds(480+40, 225, 200, 20);

        currentPanel.add(cancelOrderButton);
        cancelOrderButton.setEnabled(false);

        // New Order Button Action Listener
        createOrderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Check if customer details are filled in
                if (isThereACustomer == false) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Please fill in customer details before creating a new order.", "Missing Customer Details", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Check if there is already an existing order
                if (isOrderCreated) {
                    JOptionPane.showMessageDialog(OrderUI.this, "There is already an existing order.", "Existing Order", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                // Create a new order
                createOrderButton.setEnabled(false);
                int employeeID = Integer.parseInt(employeeIdField.getText());
                int customerID = Integer.parseInt(customerIDField.getText());

                String orderStatus = "paying later";
                double orderTotalPrice = 0; // Assuming order total price is initially 0
                int newOrderID = order.addOrder(employeeID, customerID, orderStatus, orderTotalPrice);
                if (newOrderID != 0) {
                    System.out.println("New order created successfully with Order ID: " + newOrderID);
                    isOrderCreated = true; // Update the flag indicating order creation
                    String currentID = Integer.toString(order.getOrderID());

                    customerClearButton.setEnabled(false);
                    orderIdField.setText(currentID);
                    itemIdField.setEnabled(true);
                    quantityField.setEnabled(true);
                    addButton.setEnabled(true);
                    confirmOrderButton.setEnabled(true);
                    cancelOrderButton.setEnabled(true);
                } else {
                    System.out.println("Failed to create a new order.");
                }
            }
        });

        // Complete Order Button Action Listener
        confirmOrderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the number of rows in the item table
                int rowCount = tableModel.getRowCount();
                if (rowCount == 0) {
                    JOptionPane.showMessageDialog(OrderUI.this, "No items added in the order.", "No Items", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }

                // Get the order ID
                int orderID = Integer.parseInt(orderIdField.getText());

                // Initialize total sum
                double totalSum = 0.0;

                // Iterate through the rows of the item table
                for (int i = 0; i < rowCount; i++) {
                    String itemIDString = tableModel.getValueAt(i, 0).toString(); // Item ID
                    String quantityString = tableModel.getValueAt(i, 2).toString(); // Quantity

                    // Convert String values to int
                    int itemID = Integer.parseInt(itemIDString);
                    int quantity = Integer.parseInt(quantityString);

                    // Calculate the new price as subtotal / quantity
                    double subtotal = Double.parseDouble(tableModel.getValueAt(i, 4).toString()); // Subtotal
                    double price = subtotal / quantity;

                    // Add the item to the order
                    order.addItem(orderID, itemID, quantity, price);
                    
                    totalSum += subtotal;
                }

                // Update the order total in the tbl_order table
                order.updateOrderTotal(orderID, totalSum);

                // Display the total amount on the screen
                JOptionPane.showMessageDialog(OrderUI.this, "Order total updated successfully. Total amount: " + totalSum, "Order Total Updated", JOptionPane.INFORMATION_MESSAGE);

                // Inform the user that items have been added to the order
                JOptionPane.showMessageDialog(OrderUI.this, "Items added to the order successfully.", "Items Added", JOptionPane.INFORMATION_MESSAGE);

                // Clear all fields
                orderIdField.setText("");
                firstNameField.setText("");
                lastNameField.setText("");
                contactNoField.setText("");
                unlockCustomerDetailsFields();
                customerIDField.setText("");

                updateOrderTable(orderTableModel);

                tableModel.setRowCount(0);
                
                // Reset flags and buttons
                isThereACustomer = false;
                isOrderCreated = false;
                createOrderButton.setEnabled(true);
                customerSearchButton.setEnabled(true);
                customerClearButton.setEnabled(true);
                customerEditButton.setEnabled(true);

                cancelOrderButton.setEnabled(false);
                confirmOrderButton.setEnabled(false);

                addButton.setEnabled(false);
                removeButton.setEnabled(false);
            }
        });

        cancelOrderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Check if there is an existing order
                if (!isOrderCreated) {
                    JOptionPane.showMessageDialog(OrderUI.this, "No order to cancel.", "No Order Found", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
        
                // Get the latest order ID
                int latestOrderID = order.getOrderID();
                if (latestOrderID != 0) {
                    // Cancel the order
                    if (order.deleteOrder(latestOrderID)) {
                        System.out.println("Order with ID " + latestOrderID + " canceled successfully.");
                        // Clear the order items from the table

                        // Reset flags and buttons
                        // Reset flags and buttons
                        isThereACustomer = false;
                        tableModel.setRowCount(0);
                        isOrderCreated = false; // Update the flag indicating order cancellation
        
                        createOrderButton.setEnabled(true);
                        customerSearchButton.setEnabled(true);
                        customerClearButton.setEnabled(true);
                        customerEditButton.setEnabled(true);

                        // Clear all fields
                        orderIdField.setText("");
                        firstNameField.setText("");
                        lastNameField.setText("");
                        contactNoField.setText("");
                        unlockCustomerDetailsFields();
                        customerIDField.setText("");

                        cancelOrderButton.setEnabled(false);
                        confirmOrderButton.setEnabled(false);
        
                        addButton.setEnabled(false);
                        removeButton.setEnabled(false);
        
                    } else {
                        System.out.println("Failed to cancel the order.");
                    }
                } else {
                    System.out.println("Failed to cancel the order.");
                }
            }
        });

        add(currentPanel);
        
        // All Order
        JPanel viewOrdersPanel = new JPanel();
        viewOrdersPanel.setBorder(BorderFactory.createTitledBorder("View Orders"));
        viewOrdersPanel.setLayout(null);
        viewOrdersPanel.setBounds(840, 20, 500, 650);

        JLabel orderTableLabel = new JLabel();
        orderTableLabel.setBounds(20, 20, 100, 20);
        orderTableLabel.setText("All Orders:");
        orderTableLabel.setFont(smallLabel);

        viewOrdersPanel.add(orderTableLabel);

        // Table for tbl_order
        orderTableModel = new NonEditableTableModel();
        newTbl_order = new JTable(orderTableModel);
        JScrollPane orderScrollPane = new JScrollPane(newTbl_order);
        orderScrollPane.setBounds(20, 40, 460, 250);
        viewOrdersPanel.add(orderScrollPane);

        // Add Table Headers for tbl_order
        orderTableModel.addColumn("Order ID");
        orderTableModel.addColumn("Employee ID");
        orderTableModel.addColumn("Customer ID");
        orderTableModel.addColumn("Order Status");
        orderTableModel.addColumn("Total Price");

        JLabel itemsInTableLabel = new JLabel();
        itemsInTableLabel.setBounds(20, 300, 100, 20);
        itemsInTableLabel.setText("Items:");
        itemsInTableLabel.setFont(smallLabel);

        viewOrdersPanel.add(itemsInTableLabel);

        // Table for tbl_items
        DefaultTableModel itemsTableModel = new NonEditableTableModel();
        JTable newTbl_items = new JTable(itemsTableModel);
        JScrollPane itemsScrollPane = new JScrollPane(newTbl_items);
        itemsScrollPane.setBounds(20, 320, 460, 150);
        viewOrdersPanel.add(itemsScrollPane);

        // Add Table Headers for tbl_items
        itemsTableModel.addColumn("Order ID");
        itemsTableModel.addColumn("Item ID");
        itemsTableModel.addColumn("Quantity");
        itemsTableModel.addColumn("Price");
        itemsTableModel.addColumn("Subtotal");

        // BUTTON LABELS FOR STATUS

        JLabel statusTableLabel = new JLabel();
        statusTableLabel.setBounds(20, 480, 100, 20);
        statusTableLabel.setText("Status:");
        statusTableLabel.setFont(smallLabel);

        viewOrdersPanel.add(statusTableLabel);

        JButton payingLaterButton = new JButton("Paying Later");
        payingLaterButton.setBounds(20, 510, 120, 20);
        viewOrdersPanel.add(payingLaterButton);
        payingLaterButton.setEnabled(false);

        JButton paidButton = new JButton("Paid");
        paidButton.setBounds(160, 510, 120, 20);
        viewOrdersPanel.add(paidButton);
        paidButton.setEnabled(false);

        JButton completeButton = new JButton("Complete");
        completeButton.setBounds(300, 510, 120, 20);
        viewOrdersPanel.add(completeButton);
        completeButton.setEnabled(false);

        JLabel moreOptionsTableLabel = new JLabel();
        moreOptionsTableLabel.setBounds(20, 540, 100, 20);
        moreOptionsTableLabel.setText("More Options:");
        moreOptionsTableLabel.setFont(smallLabel);

        viewOrdersPanel.add(moreOptionsTableLabel);

        JButton editOrderButton = new JButton("Edit Order");
        editOrderButton.setBounds(20, 570, 120, 20);
        viewOrdersPanel.add(editOrderButton);
        editOrderButton.setEnabled(false);

        JButton deleteOrderButton = new JButton("Delete Order");
        deleteOrderButton.setBounds(160, 570, 120, 20);
        viewOrdersPanel.add(deleteOrderButton);
        deleteOrderButton.setEnabled(false);

        JLabel toggleOrderLabel = new JLabel("Toggle Order:");
        toggleOrderLabel.setBounds(20, 600, 120, 20);
        viewOrdersPanel.add(toggleOrderLabel);
        toggleOrderLabel.setFont(smallLabel);

        JComboBox<String> toggleOrderComboBox = new JComboBox<>(new String[]{"ALL", "HIDECOMPLETE", "TODAY"});
        toggleOrderComboBox.setBounds(160, 600, 120, 20);
        viewOrdersPanel.add(toggleOrderComboBox);

        JButton clearButton = new JButton("Clear Selection");
        clearButton.setBounds(300, 570, 120, 20);
        viewOrdersPanel.add(clearButton);
        clearButton.setEnabled(false);

        JButton salesButton = new JButton("Sales Report");
        salesButton.setBounds(300, 600, 120, 20);
        viewOrdersPanel.add(salesButton);
        salesButton.setEnabled(true);

        salesButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                openSalesReport();
            }
        });

        // Add ActionListener to toggleOrderComboBox
        toggleOrderComboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                selectedOption = (String) toggleOrderComboBox.getSelectedItem();
                populateOrderTable(newTbl_order, selectedOption);
            }
        });

        // Clear Button Action Listener
        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Clear selection from both tables
                newTbl_order.clearSelection();
                newTbl_items.clearSelection();
            }
        });

        // Populate the tbl_order table
        populateOrderTable(newTbl_order, selectedOption);

        // Add ListSelectionListener to newTbl_order
        newTbl_order.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = newTbl_order.getSelectedRow();
                    if (selectedRow != -1) { // Ensure a row is selected
                        int orderID = (int) newTbl_order.getValueAt(selectedRow, 0); // Assuming order ID is in the first column
                        populateItemTable(orderID, newTbl_items); // Populate item table based on selected order ID
                        fetchOrderDetails((int) orderID);
                    }
                }
            }
        });

        // Paying Later Button Action Listener
        payingLaterButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateOrderStatus("paying later", newTbl_order);

                // Clear selection from both tables
                newTbl_order.clearSelection();
                newTbl_items.clearSelection();
            }
        });

        // Paid Button Action Listener
        paidButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateOrderStatus("paid", newTbl_order);

                // Clear selection from both tables
                newTbl_order.clearSelection();
                newTbl_items.clearSelection();
            }
        });

        // Complete Button Action Listener
        completeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateOrderStatus("complete", newTbl_order);

                // Clear selection from both tables
                newTbl_order.clearSelection();
                newTbl_items.clearSelection();
            }
        });

        // Delete Order Button Action Listener
        deleteOrderButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = newTbl_order.getSelectedRow();

                // Prompt user for passcode
                String passcode = JOptionPane.showInputDialog(OrderUI.this, "Enter passcode to cancel order:");
        
                // Check passcode
                if (passcode == null || !passcode.equals("888#1762")) {
                    JOptionPane.showMessageDialog(OrderUI.this, "Incorrect passcode. Order cancellation failed.", "Invalid Passcode", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                if (selectedRow != -1) { // Ensure a row is selected
                    int orderId = (int) newTbl_order.getValueAt(selectedRow, 0); 
                    
                    // Confirm deletion with user (optional)
                    int dialogResult = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this order?", "Warning", JOptionPane.YES_NO_OPTION);
                    if (dialogResult == JOptionPane.YES_OPTION) {
                        if (order.deleteOrder(orderId)) {
                            // If deletion is successful, refresh order table
                            populateOrderTable(newTbl_order, selectedOption);
                            // Also clear item table
                            itemsTableModel.setRowCount(0);
                        }
                    }
                }
            }
        });

        // Add ListSelectionListener to newTbl_order
        newTbl_order.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = newTbl_order.getSelectedRow();
                    if (selectedRow != -1) { // Ensure a row is selected
                        int orderID = (int) newTbl_order.getValueAt(selectedRow, 0); // Assuming order ID is in the first column
                        populateItemTable(orderID, newTbl_items); // Populate item table based on selected order ID
                        
                        // Enable all buttons
                        payingLaterButton.setEnabled(true);
                        paidButton.setEnabled(true);
                        completeButton.setEnabled(true);
                        clearButton.setEnabled(true);
                        editOrderButton.setEnabled(true);
                        deleteOrderButton.setEnabled(true);
                    } else {
                        // If no row is selected, disable all buttons
                        payingLaterButton.setEnabled(false);
                        paidButton.setEnabled(false);
                        completeButton.setEnabled(false);
                        clearButton.setEnabled(false);
                        editOrderButton.setEnabled(false);
                        deleteOrderButton.setEnabled(false);
                    }
                }
            }
        });

        editOrderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int selectedRow = newTbl_order.getSelectedRow();
                if (selectedRow != -1) { // Ensure a row is selected
                    int orderID = (int) newTbl_order.getValueAt(selectedRow, 0); // Assuming order ID is in the first column
                    EditOrderUI editOrderUI = new EditOrderUI(orderID);

                    // Get the JFrame instance from EditOrderUI
                    JFrame editOrderFrame = editOrderUI.getFrame();
                    
                    // Add window listener to detect when the frame is closed
                    editOrderFrame.addWindowListener(new WindowAdapter() {
                        @Override
                        public void windowClosed(WindowEvent e) {
                            System.out.println("Edit Order window closed.");
                            updateFast();
                        }
                    });
        
                } else {
                    // Inform the user to select a row
                    JOptionPane.showMessageDialog(null, "Please select an order to edit.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        

        add(viewOrdersPanel);

        /**
         *  MORE DETAILS
         *  
         */

        // INITIALIZING THE PANEL HERE
        JPanel moreDetailsPanel = new JPanel();
        moreDetailsPanel.setBorder(BorderFactory.createTitledBorder("More Order Details"));
        moreDetailsPanel.setLayout(null);
        moreDetailsPanel.setBounds(20, 490, 440, 150);

        // ORDER ID
        JLabel moreOrderID = new JLabel("OrderID:");
        moreOrderID.setBounds(20, 20, 240, 20);
        moreOrderID.setFont(smallLabel);

        moreOrderIDField = new JTextField();
        moreOrderIDField.setBounds(150, 20, 140, 20);
        moreOrderIDField.setFont(fieldFont);
        moreOrderIDField.setEnabled(false);

        moreDetailsPanel.add(moreOrderIDField);
        moreDetailsPanel.add(moreOrderID);

        // EMP NAME
        JLabel  moreEmpName = new JLabel("Employee Name:");
        moreEmpName.setBounds(20, 42, 200, 20);
        moreEmpName.setFont(smallLabel);
        moreEmpNameField = new JTextField();
        moreEmpNameField.setBounds(150, 42, 140, 20);
        moreEmpNameField.setFont(fieldFont);
        moreEmpNameField.setEnabled(false);

        moreDetailsPanel.add(moreEmpName);
        moreDetailsPanel.add(moreEmpNameField);

        // CUSTOMER NAME
        JLabel moreCustomerName = new JLabel("Customer Name:");
        moreCustomerName.setBounds(20, 64, 200, 20);
        moreCustomerName.setFont(smallLabel);

        moreCNameField = new JTextField();
        moreCNameField.setBounds(150, 64, 140, 20);
        moreCNameField.setFont(fieldFont);
        moreCNameField.setEnabled(false);

        moreDetailsPanel.add(moreCustomerName);
        moreDetailsPanel.add(moreCNameField);

        // CUSTOMER CONT
        JLabel moreCustomerCont = new JLabel("Contact Number:");
        moreCustomerCont.setBounds(20, 86, 200, 20);
        moreCustomerCont.setFont(smallLabel);

        moreCContField = new JTextField();
        moreCContField.setBounds(150, 86, 140, 20);
        moreCContField.setFont(fieldFont);
        moreCContField.setEnabled(false);

        moreDetailsPanel.add(moreCustomerCont);
        moreDetailsPanel.add(moreCContField);

        add(moreDetailsPanel);

        add(mainPanel);
    }

    // Method to fetch order details from the database
    private void fetchOrderDetails(int orderID) {
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "")) {
            String query = "SELECT o.Order_ID, CONCAT(e.employee_FirstName, ' ', e.employee_LastName) AS EmployeeFullName, " +
                        "CONCAT(c.Customer_FirstName, ' ', c.Customer_LastName) AS CustomerFullName, " +
                        "c.Customer_ContactNum " +
                        "FROM tbl_order o " +
                        "JOIN tbl_customer c ON o.Customer_ID = c.Customer_ID " +
                        "JOIN tbl_employee e ON o.Employee_ID = e.employee_id " +
                        "WHERE o.Order_ID = ?";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setInt(1, orderID);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        String orderIDValue = resultSet.getString("Order_ID");
                        String employeeFullName = resultSet.getString("EmployeeFullName");
                        String customerFullName = resultSet.getString("CustomerFullName");
                        String customerContact = resultSet.getString("Customer_ContactNum");
                        customerContact = "0" + customerContact;

                        // Update the text fields with fetched data
                        moreOrderIDField.setText(orderIDValue);
                        moreEmpNameField.setText(employeeFullName);
                        moreCNameField.setText(customerFullName);

                        moreCContField.setText(customerContact);
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void updateFast() {
        updateOrderTable(orderTableModel);
    }

    private void updateOrderTable(DefaultTableModel orderTableModel) {
        // Clear existing data
        orderTableModel.setRowCount(0); 
        
        // Repopulate the table model with the latest data from the database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "")) {
            String sql = "SELECT * FROM tbl_order";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int orderID = rs.getInt("Order_ID");
                int employeeID = rs.getInt("Employee_ID");
                int customerID = rs.getInt("Customer_ID");
                String orderStatus = rs.getString("Order_Status");
                double totalPrice = rs.getDouble("Order_TotalPrice");
    
                // Add row to the table model
                Object[] rowData = {orderID, employeeID, customerID, orderStatus, totalPrice};
                orderTableModel.addRow(rowData);
            }
            
            // Populate the table with color codes based on order status
            populateOrderTable(newTbl_order, selectedOption);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Method to check if the item ID exists in the product_size table
    private boolean isValidItemID(int itemId) {
        return order.verifyItemID(itemId);
    }

    private void openSalesReport() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new SalesReportViewInterface();
            }
        });
    }



    // Modify the populateOrderTable method to accept the selected option
    private void populateOrderTable(JTable newTbl_order, String selectedOption) {
        DefaultTableModel orderTableModel = (DefaultTableModel) newTbl_order.getModel();
        orderTableModel.setRowCount(0); // Clear existing data
        
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "")) {
            String sql = "SELECT * FROM tbl_order";
            
            // Modify the SQL query based on the selected option
            if (selectedOption.equals("HIDECOMPLETE")) {
                sql += " WHERE Order_Status != 'complete'";
            } else if (selectedOption.equals("TODAY")) {
                sql += " WHERE DATE(Order_Date) = CURDATE()";
            } else if (selectedOption.equals("TODAY / HIDECOMPLETED")) {
                sql += " WHERE DATE(Order_Date) = CURDATE() AND Order_Status != 'complete'";
            }
            
            PreparedStatement pstmt = conn.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                    int orderID = rs.getInt("Order_ID");
                    int employeeID = rs.getInt("Employee_ID");
                    int customerID = rs.getInt("Customer_ID");
                    String orderStatus = rs.getString("Order_Status");
                    double totalPrice = rs.getDouble("Order_TotalPrice");
                    
                    // Apply color codes based on order status
                    String colorCode = "";
                    switch (orderStatus) {
                        case "paying later":
                            colorCode = "#FFA500"; // Orange
                            break;
                        case "paid":
                            colorCode = "#00FF00"; // Green
                            break;
                        case "complete":
                            colorCode = "#0000FF"; // Blue
                            break;
                        default:
                            colorCode = "#000000"; // Black (default)
                            break;
                    }
                    
                    // Add row to the table model of tbl_order with color-coded status
                    orderTableModel.addRow(new Object[]{
                            orderID,
                            employeeID,
                            customerID,
                            "<html><font color='" + colorCode + "'>" + orderStatus + "</font></html>",
                            totalPrice
                    });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void populateItemTable(int orderID, JTable newTbl_items) {
        // Clear the existing table
        DefaultTableModel itemsTableModel = (DefaultTableModel) newTbl_items.getModel();
        itemsTableModel.setRowCount(0); // Clear existing data
    
        // Fetch items for the given order ID from the database
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "")) {
            String sql = "SELECT * FROM tbl_item WHERE Order_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, orderID);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int itemID = rs.getInt("Item_ID");
                int quantity = rs.getInt("Item_Quantity");
                double price = rs.getDouble("Item_Price");
                double subtotal = rs.getDouble("Item_Subtotal");
    
                // Add row to the table model of tbl_items
                itemsTableModel.addRow(new Object[]{orderID, itemID, quantity, price, subtotal});
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    private void updateOrderStatus(String newStatus, JTable newTbl_order) {
        int selectedRow = newTbl_order.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(OrderUI.this, "Please select an order to update its status.", "No Order Selected", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
    
        DefaultTableModel model = (DefaultTableModel) newTbl_order.getModel();
        String currentStatus = (String) model.getValueAt(selectedRow, 3);
        if (newStatus.equals(currentStatus)) {
            JOptionPane.showMessageDialog(OrderUI.this, "Order is already in '" + newStatus + "' status.", "Same Status", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
    
        int orderID = (int) model.getValueAt(selectedRow, 0);
        // Update the order status in the database
        if (updateOrderStatusInDatabase(orderID, newStatus)) {
            // Update the status in the table model
            model.setValueAt(newStatus, selectedRow, 3);
            
            // Apply color codes based on order status
            String colorCode = "";
            switch (newStatus) {
                case "paying later":
                    colorCode = "#FFA500"; // Orange
                    break;
                case "paid":
                    colorCode = "#00FF00"; // Green
                    break;
                case "complete":
                    colorCode = "#0000FF"; // Blue
                    break;
                default:
                    colorCode = "#000000"; // Black (default)
                    break;
            }
            
            // Update the color-coded status indicator
            model.setValueAt("<html><font color='" + colorCode + "'>" + newStatus + "</font></html>", selectedRow, 3);
            
            JOptionPane.showMessageDialog(OrderUI.this, "Order status updated successfully to '" + newStatus + "'.", "Status Updated", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(OrderUI.this, "Failed to update order status.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private boolean updateOrderStatusInDatabase(int orderID, String newStatus) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "")) {
            String sql = "UPDATE tbl_order SET Order_Status = ? WHERE Order_ID = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, orderID);
            int rowsUpdated = pstmt.executeUpdate();
            return rowsUpdated > 0; // Return true if at least one row is updated
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false if an exception occurs
        }
    }    
    
    // Method to check if the quantity is a positive integer
    private boolean isValidQuantity(String quantity) {
        return Pattern.matches("\\d+", quantity) && Integer.parseInt(quantity) > 0;
    }

    public static void showOrderUI(int employeeID) {
        SwingUtilities.invokeLater(() -> {
            OrderUI orderUI = new OrderUI(employeeID);
            orderUI.setVisible(true);
        });
    }

    public static void main(String[] args) {
        
    }
}
