import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginFrame extends JFrame {
    private JLabel idLabel, passcodeLabel, errorLabel;
    private JTextField idField, passcodeField;
    private JButton continueButton;
    private Connection connection;
    int employeeID;

    public LoginFrame() {
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setLocationRelativeTo(null); // Center the frame on the screen

        idLabel = new JLabel("Enter Employee ID:");
        idLabel.setBounds(10, 20, 150, 25);
        add(idLabel);

        idField = new JTextField();
        idField.setBounds(160, 20, 120, 25);
        add(idField);

        passcodeLabel = new JLabel("Enter Passcode:");
        passcodeLabel.setBounds(10, 50, 150, 25);
        add(passcodeLabel);

        passcodeField = new JPasswordField();
        passcodeField.setBounds(160, 50, 120, 25);
        add(passcodeField);

        continueButton = new JButton("CONTINUE");
        continueButton.setBounds(90, 100, 120, 30);
        add(continueButton);

        errorLabel = new JLabel();
        errorLabel.setForeground(Color.RED);
        errorLabel.setBounds(10, 140, 280, 25);
        add(errorLabel);

        // Connect to the database
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        continueButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enteredEmployeeID = idField.getText();
                String enteredPasscode = passcodeField.getText();

                if (enteredEmployeeID.equals("0000") && enteredPasscode.equals("admin")) {
                    errorLabel.setText("Admin login successful!");
                    openAdminUI();
                } else {
                    // Check if the entered Employee ID exists in the database and if its corresponding passcode matches
                    if (checkEmployee(enteredEmployeeID, enteredPasscode)) {
                        errorLabel.setText("Login successful!");
                        employeeID = Integer.parseInt(enteredEmployeeID);
                        openProgram();
                    } else {
                        errorLabel.setText("Authentication failed!");
                    }
                }
            }
        });
        setVisible(true);
    }

    private void openAdminUI() {
        JFrame adminFrame = new JFrame("Admin Panel");
        adminFrame.setSize(300, 150);
        adminFrame.setLayout(new FlowLayout());
        adminFrame.setLocationRelativeTo(null); // Center the frame on the screen
        
        JLabel idLabel = new JLabel("Enter Employee ID:");
        JTextField idField = new JTextField(10);
        JButton confirmButton = new JButton("Confirm");
        JTextArea resultArea = new JTextArea(2, 20);
        resultArea.setEditable(false);

        adminFrame.add(idLabel);
        adminFrame.add(idField);
        adminFrame.add(confirmButton);
        adminFrame.add(resultArea);

        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String empID = idField.getText();
                String encryptedID = encrypt(empID);
                resultArea.setText("Encrypted ID for Employee " + empID + ": " + encryptedID);
            }
        });

        adminFrame.setVisible(true);
    }

    // Method to check if the employee ID exists in the database and if its corresponding passcode matches
    private boolean checkEmployee(String enteredEmployeeID, String enteredPasscode) {
        try {
            PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM tbl_employee WHERE employee_id = ?");
            preparedStatement.setString(1, enteredEmployeeID);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                // Get the stored encrypted ID from the database
                String storedEncryptedID = encrypt(enteredEmployeeID);
                // Encrypt the entered employee ID
                String enteredEncryptedID = enteredPasscode;
                // Compare the encrypted IDs
                return storedEncryptedID.equals(enteredEncryptedID);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Handle SQL exception by updating the error label
            errorLabel.setText("Authentication failed! Database error.");
        }
        return false;
    }



    // Method to open the program if authentication is successful
    private void openProgram() {

        dispose();
        
        OrderUI ui = new OrderUI(employeeID);
        ui.showOrderUI(employeeID);
    }

    // Method to encrypt the employee ID into an 8-digit code using MD5 hashing
    private String encrypt(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] messageDigest = md.digest(input.getBytes());
            
            // Convert the byte array to a positive integer and take modulo 100000000 to get an 8-digit number
            int encryptedInt = Math.abs(ByteBuffer.wrap(messageDigest).getInt()) % 100000000;
            
            // Format the integer to 8 digits with leading zeros if necessary
            return String.format("%08d", encryptedInt);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }


    public static void main(String[] args) {
        // Load the MySQL JDBC driver
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        // Create and show the login frame
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new LoginFrame();
            }
        });
    }
}
