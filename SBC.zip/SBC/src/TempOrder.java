import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TempOrder extends JFrame {
    private static int lastLoggedInEmployeeID;

    public TempOrder() {
        setTitle("Employee Login");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(2, 2));

        JLabel employeeIDLabel = new JLabel("Employee ID:");
        JTextField employeeIDField = new JTextField();
        JButton loginButton = new JButton("Login");

        panel.add(employeeIDLabel);
        panel.add(employeeIDField);
        panel.add(new JLabel()); // Empty label for spacing
        panel.add(loginButton);

        add(panel);

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int employeeID = Integer.parseInt(employeeIDField.getText());
                if (authenticateEmployee(employeeID)) {
                    lastLoggedInEmployeeID = employeeID; // Set the last logged-in employee ID
                    // Proceed to the OrderUI
                    OrderUI.showOrderUI(lastLoggedInEmployeeID);
                    dispose(); // Close the login window
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid Employee ID. Please try again.");
                    employeeIDField.setText(""); // Clear the text field
                }
            }
        });
    }

    // Method to authenticate the employee using the tbl_employee table
    private boolean authenticateEmployee(int employeeID) {
        boolean isAuthenticated = false;
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "")) {
            String sql = "SELECT * FROM tbl_employee WHERE employee_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, employeeID);
            ResultSet rs = pstmt.executeQuery();
            isAuthenticated = rs.next();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return isAuthenticated;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TempOrder tempOrder = new TempOrder();
            tempOrder.setVisible(true);
        });
    }
}
