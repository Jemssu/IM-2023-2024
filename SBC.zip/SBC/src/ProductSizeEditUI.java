import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ProductSizeEditUI {

    // Text fields
    private static JTextField itemIDTextField;
    private static JTextField productIDTextField;
    private static JTextField sizeIDTextField;
    private static JTextField itemNameTextField;
    private static JTextField productPriceTextField;
    private static JTextField searchField;

    // Buttonsk
    private static JButton searchButton;
    private static JButton createButton;
    private static JButton updateButton;
    private static JButton deleteButton;
    private static JButton confirmButton;

    // Method to clear all text fields
    private static void clearFields() {
        itemIDTextField.setText("");
        productIDTextField.setText("");
        sizeIDTextField.setText("");
        itemNameTextField.setText("");
        productPriceTextField.setText("");
    }

    // Method to enable or disable text fields
    private static void setFieldsEnabled(boolean enabled) {
        productIDTextField.setEnabled(enabled);
        sizeIDTextField.setEnabled(enabled);
        itemNameTextField.setEnabled(enabled);
        productPriceTextField.setEnabled(enabled);
    }

    // Method to enable or disable buttons
    private static void setButtonsEnabled(boolean enabled) {
        searchButton.setEnabled(enabled);
        createButton.setEnabled(enabled);
        updateButton.setEnabled(enabled);
        deleteButton.setEnabled(enabled);
        confirmButton.setEnabled(false);
    }

    // Method to reset buttons and fields to their default state
    private static void resetButtonsAndFields() {
        // Reset buttons
        createButton.setText("CREATE");
        createButton.setBackground(UIManager.getColor("Button.background"));
        setButtonsEnabled(true);

        // Reset fields
        clearFields();
        setFieldsEnabled(false);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                openPSEditUI();
            }
        });
    }

    public static void openPSEditUI() {
        // Create JFrame
        JFrame frame = new JFrame("Edit Product Size Details (LARGE PANEL)");
        frame.setSize(1140, 460); // Set frame size
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(null); // Use absolute positioning

        // TITLE HEADER THINGY
        JLabel header = new JLabel("Item ID:");
        header.setBounds(20, 20, 250, 20);
        frame.add(header);
        header.setFont(new Font("Arial", Font.BOLD, 14));

        itemIDTextField = new JTextField();
        itemIDTextField.setBounds(150, 20, 200, 20);
        itemIDTextField.setEditable(false); // Make it read-only
        frame.add(itemIDTextField);

        // Create Product Size Panel
        JPanel productSizePanel = new JPanel();
        productSizePanel.setBorder(BorderFactory.createTitledBorder("Product Size Details"));
        productSizePanel.setLayout(null);
        productSizePanel.setBounds(10, 50, 350, 150);
        frame.add(productSizePanel);

        // Product ID Label and TextField
        JLabel productIDLabel = new JLabel("Product ID:");
        productIDLabel.setBounds(20, 20, 150, 20);
        productSizePanel.add(productIDLabel);
        productIDLabel.setFont(new Font("Arial", Font.BOLD, 14));

        productIDTextField = new JTextField();
        productIDTextField.setBounds(120, 20, 200, 20);
        productSizePanel.add(productIDTextField);

        // Size ID Label and TextField
        JLabel sizeIDLabel = new JLabel("Size ID:");
        sizeIDLabel.setBounds(20, 50, 150, 20);
        productSizePanel.add(sizeIDLabel);
        sizeIDLabel.setFont(new Font("Arial", Font.BOLD, 14));

        sizeIDTextField = new JTextField();
        sizeIDTextField.setBounds(120, 50, 200, 20);
        productSizePanel.add(sizeIDTextField);

        // Product Name Label and TextField
        JLabel itemNameLabel = new JLabel("Item Name:");
        itemNameLabel.setBounds(20, 80, 150, 20);
        productSizePanel.add(itemNameLabel);
        itemNameLabel.setFont(new Font("Arial", Font.BOLD, 14));

        itemNameTextField = new JTextField();
        itemNameTextField.setBounds(120, 80, 200, 20);
        productSizePanel.add(itemNameTextField);

        // Product Price Label and TextField
        JLabel productPriceLabel = new JLabel("Item Price:");
        productPriceLabel.setBounds(20, 110, 150, 20);
        productSizePanel.add(productPriceLabel);
        productPriceLabel.setFont(new Font("Arial", Font.BOLD, 14));

        productPriceTextField = new JTextField();
        productPriceTextField.setBounds(120, 110, 200, 20);
        productSizePanel.add(productPriceTextField);

        // Create Operation Panel
        JPanel operPanel = new JPanel();
        operPanel.setBorder(BorderFactory.createTitledBorder("Operation Buttons"));
        operPanel.setLayout(new GridLayout(5, 1));
        operPanel.setBounds(10, 200, 350, 200);
        frame.add(operPanel);

        // Create Button
        createButton = new JButton("CREATE");
        operPanel.add(createButton);

        // Clear Button
        confirmButton = new JButton("CONFIRM");
        operPanel.add(confirmButton);

        // Update Button
        updateButton = new JButton("UPDATE");
        operPanel.add(updateButton);

        // Delete Button
        deleteButton = new JButton("DELETE");
        operPanel.add(deleteButton);

        // Cancel Button
        JButton cancelButton = new JButton("CANCEL");
        operPanel.add(cancelButton);

        // Search Field and Button
        searchField = new JTextField();
        searchField.setBounds(400, 10, 200, 20);
        frame.add(searchField);

        searchButton = new JButton("Search");
        searchButton.setBounds(610, 10, 100, 20);
        frame.add(searchButton);

        // JTable to display product size data
        JTable table = new JTable() {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells non-editable
                return false;
            }
        };
        JScrollPane scrollPane = new JScrollPane(table); // Add the table to a scroll pane
        scrollPane.setBounds(400, 40, 700, 360);
        frame.add(scrollPane); // Add the scroll pane to the frame

        // Fetch data from database and populate the table
        updateTable(table, frame);

        resetButtonsAndFields();

        // Search Button ActionListener
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Get the search text from the search field
                String searchText = searchField.getText().trim();

                // Get the table model
                DefaultTableModel model = (DefaultTableModel) table.getModel();

                // Create a row sorter for the table
                TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
                table.setRowSorter(sorter);

                // Apply a filter based on the search text
                if (searchText.length() == 0) {
                    // If the search text is empty, remove any existing filter
                    sorter.setRowFilter(null);
                } else {
                    // Apply a regex filter to match the search text
                    sorter.setRowFilter(RowFilter.regexFilter("(?i)" + searchText)); // (?i) makes the search
                                                                                     // case-insensitive
                }
            }
        });

        // Update Button ActionListener
        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Check if a row is selected
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "Please select a row to update.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Get the selected product size details
                int itemID = (int) table.getValueAt(selectedRow, 0);
                int productID = (int) table.getValueAt(selectedRow, 1);
                int sizeID = (int) table.getValueAt(selectedRow, 2);
                String itemName = (String) table.getValueAt(selectedRow, 3);
                double productPrice = (double) table.getValueAt(selectedRow, 4);

                // Populate the text fields with the selected product size details
                itemIDTextField.setText(String.valueOf(itemID));
                productIDTextField.setText(String.valueOf(productID));
                sizeIDTextField.setText(String.valueOf(sizeID));
                itemNameTextField.setText(itemName);
                productPriceTextField.setText(String.valueOf(productPrice));

                // Enable text fields for editing
                setFieldsEnabled(true);

                // Disable other buttons
                setButtonsEnabled(false);
                itemNameTextField.setEnabled(false);

                // Unlock the table
                table.setEnabled(false);

                // Enable Confirm button
                confirmButton.setEnabled(true);
            }
        });

        createButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (createButton.getText().equals("CREATE")) {
                    // Lock the table
                    table.setEnabled(false);
                    // Clear text fields
                    clearFields();
        
                    // Enable text fields
                    setFieldsEnabled(true);
        
                    // Disable other buttons
                    setButtonsEnabled(false);
                    createButton.setEnabled(true);
                    itemNameTextField.setEnabled(false);
        
                    // Change CREATE button to SAVE
                    createButton.setBackground(Color.GREEN);
                    createButton.setText("SAVE");
                } else if (createButton.getText().equals("SAVE")) {
                    // Unlock the table
                    table.setEnabled(true);
        
                    // Get product ID, size ID, product name, and product price from text fields
                    String productIDText = productIDTextField.getText();
                    String sizeIDText = sizeIDTextField.getText();
                    String productName = ""; // Initialize productName
                    double productPrice = 0.0; // Initialize productPrice
        
                    // Validate product ID and size ID
                    try {
                        // Check if product ID and size ID are not empty
                        if (productIDText.isEmpty() || sizeIDText.isEmpty()) {
                            JOptionPane.showMessageDialog(frame, "Product ID and Size ID cannot be empty.", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        }
        
                        int productID = Integer.parseInt(productIDText);
                        int sizeID = Integer.parseInt(sizeIDText);
        
                        // Check if product ID and size ID are valid
                        if (!checkProductID(productID)) {
                            JOptionPane.showMessageDialog(frame, "Invalid Product ID.", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        }
        
                        if (!checkSizeID(sizeID)) {
                            JOptionPane.showMessageDialog(frame, "Invalid Size ID.", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        }
        
                        // Check if the combination of productID and sizeID already exists
                        if (checkProductSizeCombination(productID, sizeID)) {
                            JOptionPane.showMessageDialog(frame, "Product with Product ID: " + productID +
                                    " and Size ID: " + sizeID + " already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                            return;
                        }
        
                        // Fetch product name from tbl_product based on product ID
                        productName = fetchProductName(productID);
        
                        // Fetch size length from tbl_size based on size ID
                        String sizeLength = fetchSizeLength(sizeID);
        
                        // Concatenate product name and size length to form item name
                        String itemName = productName + " " + sizeLength;
        
                        // Validate product price
                        String productPriceText = productPriceTextField.getText();
                        if (!productPriceText.matches("\\d+(\\.\\d+)?")) {
                            JOptionPane.showMessageDialog(frame, "Product price must be a valid number.", "Error",
                                    JOptionPane.ERROR_MESSAGE);
                            return;
                        }
                        productPrice = Double.parseDouble(productPriceText);
        
                        // Prompt the user for confirmation
                        int option = JOptionPane.showConfirmDialog(frame, "Add the following product?\n\n" +
                                "Product ID: " + productID + "\n" +
                                "Item Name: " + itemName + "\n" +
                                "Product Price: " + productPrice + "\n\n" +
                                "Confirm addition?", "Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);
        
                        if (option == JOptionPane.YES_OPTION) {
                            // Insert new record into tbl_product_size
                            insertProductSizeRecord(productID, sizeID, itemName, productPrice);
        
                            // Display success message
                            JOptionPane.showMessageDialog(frame, "Product size record added successfully!");
        
                            // Reset buttons and fields
                            resetButtonsAndFields();
                            updateTable(table, frame);
                        } else if (option == JOptionPane.NO_OPTION) {
                            // Reset buttons and fields
                            resetButtonsAndFields();
                        }
                        // For "Cancel" option, do nothing
        
                        // Unlock the table
                        table.setEnabled(true);
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(frame, "Product ID and Size ID must be integers.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }
        });

        updateTable(table, frame);
        
        // Delete Button ActionListener
        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Check if a row is selected
                int selectedRow = table.getSelectedRow();
                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(frame, "Please select a row to delete.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Get the product ID of the selected row
                int itemID = (int) table.getValueAt(selectedRow, 0);

                // Prompt the user for confirmation
                int option = JOptionPane.showConfirmDialog(frame, "Are you sure you want to delete the product with Item ID: " + itemID + "?", "Confirmation", JOptionPane.YES_NO_OPTION);

                if (option == JOptionPane.YES_OPTION) {
                    // Delete the row from the database based on the product ID
                    deleteProductSizeRecord(itemID);

                    // Display success message
                    JOptionPane.showMessageDialog(frame, "Product size record deleted successfully!");

                    // Update the table
                    updateTable(table, frame);
                }
            }
        });

        // Confirm Button ActionListener
        confirmButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Unlock the table
                table.setEnabled(true);
                
                // Get product ID, size ID, product name, and product price from text fields
                String productIDText = productIDTextField.getText();
                String sizeIDText = sizeIDTextField.getText();
                String productName = ""; // Initialize productName
                double productPrice = 0.0; // Initialize productPrice
                String itemIDText = itemIDTextField.getText();
    
                // Validate product ID and size ID
                try {
                    // Check if product ID and size ID are not empty
                    if (productIDText.isEmpty() || sizeIDText.isEmpty()) {
                        JOptionPane.showMessageDialog(frame, "Product ID and Size ID cannot be empty.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
    
                    int productID = Integer.parseInt(productIDText);
                    int sizeID = Integer.parseInt(sizeIDText);
    
                    // Check if product ID and size ID are valid
                    if (!checkProductID(productID)) {
                        JOptionPane.showMessageDialog(frame, "Invalid Product ID.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
    
                    if (!checkSizeID(sizeID)) {
                        JOptionPane.showMessageDialog(frame, "Invalid Size ID.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
    
                    // Check if the combination of productID and sizeID already exists
                    if (checkProductSizeCombination(productID, sizeID)) {
                        JOptionPane.showMessageDialog(frame, "Product with Product ID: " + productID +
                                " and Size ID: " + sizeID + " already exists.", "Error", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
    
                    // Fetch product name from tbl_product based on product ID
                    productName = fetchProductName(productID);
    
                    // Fetch size length from tbl_size based on size ID
                    String sizeLength = fetchSizeLength(sizeID);
    
                    // Concatenate product name and size length to form item name
                    String itemName = productName + " " + sizeLength;
    
                    // Validate product price
                    String productPriceText = productPriceTextField.getText();
                    if (!productPriceText.matches("\\d+(\\.\\d+)?")) {
                        JOptionPane.showMessageDialog(frame, "Product price must be a valid number.", "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    productPrice = Double.parseDouble(productPriceText);
    
                    // Prompt the user for confirmation
                    int option = JOptionPane.showConfirmDialog(frame, "Update the following product?\n\n" +
                            "Product ID: " + productID + "\n" +
                            "Item Name: " + itemName + "\n" +
                            "Product Price: " + productPrice + "\n\n" +
                            "Confirm addition?", "Confirmation", JOptionPane.YES_NO_CANCEL_OPTION);
    
                    if (option == JOptionPane.YES_OPTION) {
                        // Insert new record into tbl_product_size
                        updateProductSizeRecord(Integer.parseInt(itemIDText), productID, sizeID, itemName, productPrice);
    
                        // Display success message
                        JOptionPane.showMessageDialog(frame, "Product size record updated successfully!");
    
                        // Reset buttons and fields
                        resetButtonsAndFields();
                        updateTable(table, frame);
                    } else if (option == JOptionPane.NO_OPTION) {
                        // Reset buttons and fields
                        resetButtonsAndFields();
                    }
                    // For "Cancel" option, do nothing
    
                    // Unlock the table
                    table.setEnabled(true);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(frame, "Product ID and Size ID must be integers.", "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }
        });

        // Cancel Button ActionListener
        cancelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Reset buttons and fields
                resetButtonsAndFields();

                // Disable Confirm button
                confirmButton.setEnabled(false);

                // Unlock the table
                table.setEnabled(true);
            }
        });
        
        // Add ListSelectionListener to the table
        table.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (!e.getValueIsAdjusting()) {
                    int selectedRow = table.getSelectedRow();
                    if (selectedRow != -1) { // Check if a row is selected
                        // Populate text fields with data from the selected row
                        itemIDTextField.setText(table.getValueAt(selectedRow, 0).toString());
                        productIDTextField.setText(table.getValueAt(selectedRow, 1).toString());
                        sizeIDTextField.setText(table.getValueAt(selectedRow, 2).toString());
                        itemNameTextField.setText(table.getValueAt(selectedRow, 3).toString());
                        productPriceTextField.setText(table.getValueAt(selectedRow, 4).toString());
                    }
                }
            }
        });


        // Set frame visible
        frame.setVisible(true);
    }

    // Method to update a record in tbl_product_size
    private static void updateProductSizeRecord(int itemID, int productID, int sizeID, String itemName, double productPrice) {
        try {
            // JDBC URL, username, and password
            String url = "jdbc:mysql://localhost:3306/prj_tan";
            String username = "root";
            String password = "";

            // Create database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to update record in tbl_product_size
            String query = "UPDATE tbl_product_size SET Product_ID = ?, Size_ID = ?, Item_Name = ?, Item_Price = ? WHERE Item_ID = ?";

            // Create prepared statement
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productID);
            preparedStatement.setInt(2, sizeID);
            preparedStatement.setString(3, itemName);
            preparedStatement.setDouble(4, productPrice);
            preparedStatement.setInt(5, itemID);

            // Execute update
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Record updated successfully.");
            } else {
                System.out.println("Failed to update record.");
            }

            // Close resources
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to update record in the database!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

        // Method to delete a record from tbl_product_size based on the product ID
        private static void deleteProductSizeRecord(int Item_ID) {
            try {
                // JDBC URL, username, and password
                String url = "jdbc:mysql://localhost:3306/prj_tan";
                String username = "root";
                String password = "";
    
                // Create database connection
                Connection connection = DriverManager.getConnection(url, username, password);
    
                // SQL query to delete record from tbl_product_size
                String query = "DELETE FROM tbl_product_size WHERE Item_ID = ?";
    
                // Create prepared statement
                PreparedStatement preparedStatement = connection.prepareStatement(query);
                preparedStatement.setInt(1, Item_ID);
    
                // Execute update
                int rowsAffected = preparedStatement.executeUpdate();
    
                if (rowsAffected > 0) {
                    System.out.println("Record deleted successfully.");
                } else {
                    System.out.println("Failed to delete record.");
                }
    
                // Close resources
                preparedStatement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "Failed to delete record from the database!", "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

    // Method to check if the combination of productID and sizeID already exists in tbl_product_size
    private static boolean checkProductSizeCombination(int productID, int sizeID) {
        boolean exists = false;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
            String query = "SELECT * FROM tbl_product_size WHERE Product_ID = ? AND Size_ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productID);
            preparedStatement.setInt(2, sizeID);
            ResultSet resultSet = preparedStatement.executeQuery();
            exists = resultSet.next();
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exists;
    }

    // Method to update the table with the latest data from the database
    private static void updateTable(JTable table, JFrame frame) {
        try {
            // JDBC URL, username, and password
            String url = "jdbc:mysql://localhost:3306/prj_tan";
            String username = "root";
            String password = "";

            // Create database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to fetch data from tbl_product_size
            String query = "SELECT * FROM tbl_product_size";

            // Create prepared statement
            PreparedStatement preparedStatement = connection.prepareStatement(query);

            // Execute query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Create a DefaultTableModel to store the data
            DefaultTableModel model = new DefaultTableModel();
            // Add column headers to the model
            model.addColumn("Item ID");
            model.addColumn("Product ID");
            model.addColumn("Size ID");
            model.addColumn("Item Name");
            model.addColumn("Item Price");

            // Populate the model with data from the result set
            while (resultSet.next()) {
                Object[] row = new Object[5];
                row[0] = resultSet.getInt("item_ID");
                row[1] = resultSet.getInt("Product_ID");
                row[2] = resultSet.getInt("Size_ID");
                row[3] = resultSet.getString("Item_Name");
                row[4] = resultSet.getDouble("Item_Price");
                model.addRow(row);
            }

            // Set the table model
            table.setModel(model);

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to fetch data from the database!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    

    // Method to check if the product ID exists in tbl_product
    private static boolean checkProductID(int productID) {
        boolean valid = false;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
            String query = "SELECT * FROM tbl_product WHERE product_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productID);
            ResultSet resultSet = preparedStatement.executeQuery();
            valid = resultSet.next();
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return valid;
    }

    // Method to check if the size ID exists in tbl_size
    private static boolean checkSizeID(int sizeID) {
        boolean valid = false;
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/prj_tan", "root", "");
            String query = "SELECT * FROM tbl_size WHERE size_ID = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, sizeID);
            ResultSet resultSet = preparedStatement.executeQuery();
            valid = resultSet.next();
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return valid;
    }

    // Method to fetch product name from tbl_product based on product ID
    private static String fetchProductName(int productID) {
        String productName = "";
        try {
            // JDBC URL, username, and password
            String url = "jdbc:mysql://localhost:3306/prj_tan";
            String username = "root";
            String password = "";

            // Create database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to fetch product name
            String query = "SELECT Product_Name FROM tbl_product WHERE Product_ID = ?";

            // Create prepared statement
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productID);

            // Execute query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if result set has next
            if (resultSet.next()) {
                productName = resultSet.getString("Product_Name");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch product name from the database!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
        return productName;
    }

    // Method to fetch size length from tbl_size based on size ID
    private static String fetchSizeLength(int sizeID) {
        String sizeLength = "";
        try {
            // JDBC URL, username, and password
            String url = "jdbc:mysql://localhost:3306/prj_tan";
            String username = "root";
            String password = "";

            // Create database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to fetch size length
            String query = "SELECT Size_Length FROM tbl_size WHERE Size_ID = ?";

            // Create prepared statement
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, sizeID);

            // Execute query
            ResultSet resultSet = preparedStatement.executeQuery();

            // Check if result set has next
            if (resultSet.next()) {
                sizeLength = resultSet.getString("Size_Length");
            }

            // Close resources
            resultSet.close();
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to fetch size length from the database!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
        return sizeLength;
    }

    // Method to insert new record into tbl_product_size
    private static void insertProductSizeRecord(int productID, int sizeID, String itemName, double productPrice) {
        try {
            // JDBC URL, username, and password
            String url = "jdbc:mysql://localhost:3306/prj_tan";
            String username = "root";
            String password = "";

            // Create database connection
            Connection connection = DriverManager.getConnection(url, username, password);

            // SQL query to insert record into tbl_product_size
            String query = "INSERT INTO tbl_product_size (Product_ID, Size_ID, Item_Name, Item_Price) VALUES (?, ?, ?, ?)";

            // Create prepared statement
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, productID);
            preparedStatement.setInt(2, sizeID);
            preparedStatement.setString(3, itemName);
            preparedStatement.setDouble(4, productPrice);

            // Execute update
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("New record inserted successfully.");
            } else {
                System.out.println("Failed to insert new record.");
            }

            // Close resources
            preparedStatement.close();
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to insert new record into the database!", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
